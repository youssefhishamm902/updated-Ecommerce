import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AliasManagementComponent } from './alias-management/alias-management.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: AliasManagementComponent
  }
];

@NgModule({
  declarations: [
    AliasManagementComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule
  ]
})
export class AliasManagementModule { }
