import { Component } from '@angular/core';

@Component({
  selector: 'app-alias-management',
  templateUrl: './alias-management.component.html',
  styleUrls: ['./alias-management.component.scss']
})
export class AliasManagementComponent {

}
