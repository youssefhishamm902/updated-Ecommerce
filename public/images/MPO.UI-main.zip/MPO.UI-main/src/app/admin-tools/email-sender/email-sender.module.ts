import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailSenderComponent } from './email-sender/email-sender.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: EmailSenderComponent
  }
];

@NgModule({
  declarations: [
    EmailSenderComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule
  ]
})
export class EmailSenderModule { }
