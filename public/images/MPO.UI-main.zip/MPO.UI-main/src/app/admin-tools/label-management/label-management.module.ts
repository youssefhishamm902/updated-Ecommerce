import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LabelManagementComponent } from './label-management/label-management.component';
import { AddLabelComponent } from './add-label/add-label.component';
import { RouterModule, Routes } from '@angular/router';
import { ToolbarModule } from 'primeng/toolbar';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiSelectModule } from 'primeng/multiselect';
import { PaginatorModule } from 'primeng/paginator';
import { ChipsModule } from 'primeng/chips';
import { CheckboxModule } from 'primeng/checkbox';
import { MenubarModule } from 'primeng/menubar';
import { DropdownModule } from 'primeng/dropdown';
import { ToastModule } from 'primeng/toast';
import { MenuModule } from 'primeng/menu';
import { SharedModule } from "../../../shared/components/shared.module";

const routes: Routes = [
  {
    path: '',
    component: LabelManagementComponent
  },
  {
    path: 'add-label',
    component: AddLabelComponent
  },
];

@NgModule({
    declarations: [
        LabelManagementComponent,
        AddLabelComponent
    ],
    imports: [
        RouterModule.forChild(routes),
        CommonModule,
        SharedModule,
        FormsModule,
        ToolbarModule,
        ReactiveFormsModule,
        TableModule,
        MultiSelectModule,
        PaginatorModule,
        ChipsModule,
        CheckboxModule,
        MenubarModule,
        ReactiveFormsModule,
        DropdownModule,
        ToastModule,
        MenuModule
    ]
})
export class LabelManagementModule { }
