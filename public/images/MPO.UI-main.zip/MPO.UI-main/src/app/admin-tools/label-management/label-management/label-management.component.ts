import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import { Router } from '@angular/router';
import { Dialog } from 'primeng/dialog';
import { Table } from 'primeng/table';
import { MenuItem, PrimeNGConfig } from 'primeng/api';
import { MessageService } from 'primeng/api';
import Jsona from 'jsona';
import { AppConfig } from 'src/app/app.config';
import { Subject, takeUntil } from 'rxjs';
import { LabelService } from '../shared/services/label.service';
import { DataTableConfig, DefaultDataTableConfig } from 'src/shared/models/pagination.model';
import { Label, PaginatedLabels } from '../shared/models/label.model';
import { SpinnerService } from 'src/core/services/spinner.service';

@Component({
  selector: 'app-label-management',
  templateUrl: './label-management.component.html',
  styleUrls: ['./label-management.component.scss'],
  providers: [LabelService],
})

export class LabelManagementComponent implements OnInit {
  @ViewChild('dt') table!: Table;
  @ViewChild('searchInput') searchInput!: ElementRef;
  @ViewChild('menuContainer', { static: true }) menuContainer!: ElementRef;
  public apiServer = AppConfig.settings.apiServer;
  public unsubscribe$ = new Subject();
  labelIconsURL = this.apiServer.reportersIconsUrl;

  dataTableConfig: DataTableConfig = { ...DefaultDataTableConfig };
  tableData: Label[] = [];
  totalDataLength = 0;
  @ViewChild('addLabelDialog', { static: false }) dialoge!: Dialog;
  addLabelDialogVisible: boolean = false;
  
  ngOnInit(): void {
    this.dataTableConfig.sortProperty = 'title';

    this.getLabels();
  }

  constructor(
    private router: Router,
    private labelService: LabelService,
    private spinnerService: SpinnerService
  ) {
  }
  filterData(event: any): void {
    this.dataTableConfig.searchString = event.target.value.trim();
    this.getLabels();
  }

  onSort(event: any) {
    if (event && event.field) {
      this.dataTableConfig.sortProperty = 'title';
      if (event.order === 1) {
        this.dataTableConfig.sortOrder = 'asc';
      } else {
        this.dataTableConfig.sortOrder = 'desc';
      }

      this.getLabels();
    }
  }

  getMenuItems(status: string): MenuItem[] {
      return [
        { label: 'Edit label settings' },
        { label: 'Go to user management'},
        { separator: true },
        {
          label: 'Delete label',
          command: () => {
           // this.delete();
          },
        }
      ];
  }
  onPageChange(event: any) {
    this.dataTableConfig.paginationConfig.pageIndex = event.first + 1;
    this.dataTableConfig.paginationConfig.pageSize = event.rows;
    this.getLabels();
  }
  getLabels() {
    this.spinnerService.show();
    this.labelService
      .getLabels(this.dataTableConfig)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((res: PaginatedLabels) => {
        this.tableData = res.data;
        this.totalDataLength = res.total;
        this.spinnerService.hide();
      });
  }

  showAddLabelDialog() {
    this.addLabelDialogVisible = true;
  }

  routing() {
    this.router.navigate(['/create']);
  }
}