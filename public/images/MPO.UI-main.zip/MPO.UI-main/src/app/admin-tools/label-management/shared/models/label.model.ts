import { PaginatedData } from "src/shared/models/pagination.model";

export interface Label {
    id: number;
    title: string;
    parentBoard:Label;
    created:Date;
  }

export interface PaginatedLabels extends PaginatedData {
    data: Label[];
  }