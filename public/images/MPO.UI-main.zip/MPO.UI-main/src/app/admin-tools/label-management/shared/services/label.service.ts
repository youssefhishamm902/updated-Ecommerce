import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfig } from '../../../../app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataTableConfig } from 'src/shared/models/pagination.model';
import { PaginatedLabels } from '../models/label.model';
import { CommonHelper } from 'src/core/helpers/common-helper';

@Injectable({
  providedIn: 'root',
})

export class LabelService {
  headers = new HttpHeaders();

  protected managementServiceUrl = AppConfig.settings.apiServer.managementServiceUrl;

  constructor(private httpClient: HttpClient, private commonHelper: CommonHelper) {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!)
      .authenticated.access_token;
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + token,
    });
  }

  getLabels(dataTableConfig: DataTableConfig) {
    let options = { headers: this.headers };
    let urlQuery = this.commonHelper.composeQuery(dataTableConfig);

    return this.httpClient.get<PaginatedLabels>(
      this.managementServiceUrl + '/Label?' + urlQuery, options
    );
  }
}
