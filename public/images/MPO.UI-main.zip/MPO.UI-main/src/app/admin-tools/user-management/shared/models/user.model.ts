import { PaginatedData } from "src/shared/models/pagination.model";

export interface LabelUser {
  user:User;
  role:Role;
  }
  export interface User {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    hasImage:boolean;
    imagePath:string;
 
    position:string;
    invitation:Invitation;
  }
  export interface Role {
    id: number;
    name: string;
  }

  export interface Invitation {
    id: number;
    isAccepted: boolean;
    lastResend: Date;
    created: Date;
  }

export interface PaginatedLabelUsers extends PaginatedData {
    data: LabelUser[];
  }