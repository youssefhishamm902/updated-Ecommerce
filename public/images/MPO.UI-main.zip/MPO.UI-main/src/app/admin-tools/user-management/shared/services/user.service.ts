import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AppConfig } from '../../../../app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataTableConfig } from 'src/shared/models/pagination.model';
import { CommonHelper } from 'src/core/helpers/common-helper';
import { PaginatedLabelUsers } from '../models/user.model';

@Injectable({
  providedIn: 'root',
})

export class UserService {
  headers = new HttpHeaders();

  protected managementServiceUrl = AppConfig.settings.apiServer.managementServiceUrl;

  constructor(private httpClient: HttpClient, private commonHelper: CommonHelper) {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!)
      .authenticated.access_token;
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + token,
    });
  }

  getLabelUsers(dataTableConfig: DataTableConfig, boardId:number) {
    let options = { headers: this.headers };
    let urlQuery = "boardId="+boardId + "&" + this.commonHelper.composeQuery(dataTableConfig);

    return this.httpClient.get<PaginatedLabelUsers>(
      this.managementServiceUrl + '/User/LabelUsers?' + urlQuery, options
    );
  }
}
