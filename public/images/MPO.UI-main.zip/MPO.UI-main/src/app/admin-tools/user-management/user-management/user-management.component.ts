import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/services/user.service';
import { LabelUser, PaginatedLabelUsers, User } from '../shared/models/user.model';
import { Subject, takeUntil } from 'rxjs';
import { DataTableConfig, DefaultDataTableConfig } from 'src/shared/models/pagination.model';
import { AppConfig } from 'src/app/app.config';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { SpinnerService } from 'src/core/services/spinner.service';

export const AVATAR_COLORS = [
  'marley-light',
  'miles-light',
  'stones-light',
  'beatles-light',
  'prince-light'
] as const;

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss'],
  providers: [UserService],
})

export class UserManagementComponent implements OnInit {
  public apiServer = AppConfig.settings.apiServer;
  public unsubscribe$ = new Subject();
  dataTableConfig: DataTableConfig = { ...DefaultDataTableConfig };
  tableData: LabelUser[] = [];
  totalDataLength = 0;


  ngOnInit(): void {
    this.dataTableConfig.sortProperty = 'user';

    this.getLabelUsers();
  }

  constructor(
    private userService: UserService,
    private spinnerService: SpinnerService
  ) {
  }

  onSort(event: any) {
    if (event && event.field) {
      this.dataTableConfig.sortProperty = event.field;
      if (event.order === 1) {
        this.dataTableConfig.sortOrder = 'asc';
      } else {
        this.dataTableConfig.sortOrder = 'desc';
      }

      this.getLabelUsers();
    }
  }
  onPageChange(event: any) {
    this.dataTableConfig.paginationConfig.pageIndex = event.first + 1;
    this.dataTableConfig.paginationConfig.pageSize = event.rows;
    this.getLabelUsers();
  }
  getLabelUsers() {
    this.spinnerService.show();
   var boardId = JSON.parse(localStorage.getItem('currentUser')!).board.id;
    this.userService
      .getLabelUsers(this.dataTableConfig,boardId)
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((res: PaginatedLabelUsers) => {
        this.tableData = res.data;
        this.totalDataLength = res.total;
        this.spinnerService.hide();
      });
  }
  getDate(created: string): string {
    const currentDate = new Date();
    const createdDate = new Date(created);
    const diffTime = Math.abs(currentDate.getTime() - createdDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays >= 365) {
      const diffYears = Math.floor(diffDays / 365);
      return `${diffYears} year${diffYears > 1 ? 's' : ''} ago`;
    } else if (diffDays >= 30) {
      const diffMonths = Math.floor(diffDays / 30);
      return `${diffMonths} month${diffMonths > 1 ? 's' : ''} ago`;
    } else {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    }
  }
  hasWritePermissions()
  {
   return JSON.parse(localStorage.getItem('currentUser')!).board.permissions.boardUsers.indexOf('Write') > -1;
  }
  getUserInitials(user: User)
  {
return (user.firstName.charAt(0).toUpperCase()+user.lastName.charAt(0).toUpperCase());
  }
  colorForInitials(user: User) {
    let mod = this.getUserInitials(user).charCodeAt(0);

    return `is-${AVATAR_COLORS[mod % AVATAR_COLORS.length]}`;
  }
}
