export interface IAppConfig {
  env: {
    name: string;
  };
  apiServer: {
    authAPI: string;
    metafireSuiteAPI: string;
    reportersIconsUrl: string;
    disputeIconsUrl: string;
    managementServiceUrl:string;
    reportServiceUrl:string;
  };
  exportTimeout: number;
}
