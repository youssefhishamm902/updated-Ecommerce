import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { authGuard } from '../shared/guards/auth.guard';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'reports',
    loadChildren: () => import('./reports/reports.module').then(m => m.ReportsModule),
    canActivate: [authGuard],
  },
  {
    path: 'report-items',
    loadChildren: () => import('./report-items/reports-items.module').then(m => m.ReportItemsModule),
    canActivate: [authGuard]
  },
  {
    path: 'disputes',
    loadChildren: () => import('./disputes/disputes.module').then(m => m.DisputesModule),
    canActivate: [authGuard]
  },
  {
    path: 'emailsender',
    loadChildren: () => import('../app/admin-tools/email-sender/email-sender.module').then(m => m.EmailSenderModule),
    canActivate: [authGuard],
  },
  {
    path: 'statistics',
    loadChildren: () => import('./statistics/statistics.module').then(m => m.StatisticsModule),
    canActivate: [authGuard],
  },
  {
    path: 'finance',
    loadChildren: () => import('./finance/finance.module').then(m => m.FinanceModule),
    canActivate: [authGuard],
  },
  {
    path: 'user-management',
    loadChildren: () => import('../app/admin-tools/user-management/user-management.module').then(m => m.UserManagementModule),
    canActivate: [authGuard],
  },
  {
    path: 'label-management',
    loadChildren: () => import('../app/admin-tools/label-management/label-management.module').then(m => m.LabelManagementModule),
    canActivate: [authGuard],
  },
  {
    path: 'alias-management',
    loadChildren: () => import('../app/admin-tools/alias-management/alias-management.module').then(m => m.AliasManagementModule),
    canActivate: [authGuard],
  },
  {
    path: 'profile-settings',
    loadChildren: () => import('./user/user.module').then(m => m.UserModule),
    canActivate: [authGuard],
  },
  // otherwise redirect to home
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),

  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
