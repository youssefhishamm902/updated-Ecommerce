import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AuthenticationService } from '../core/services/authentication.service';
import { TranslateService } from "@ngx-translate/core";
import { environment } from 'src/environments/environment.production';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'mpo-frontend';
  currentUser: any = null;
  items: MenuItem[] | undefined;
  userMenuItems: MenuItem[] | undefined;
  isloggedin !: boolean;
  // test line

  constructor(
    private router: Router,
    public authService: AuthenticationService,
    private translate: TranslateService
  ) {
    this.currentUser = localStorage.getItem("currentUser");
    this.translate.setDefaultLang(environment.language1);
    this.translate.use(environment.language1);
  }



  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
    this.authService.loggedIn.next(false);

  }

  isTokenExpired(token: string) {
    const expiry = (JSON.parse(atob(token.split('.')[1]))).exp;
    return expiry * 1000 > Date.now();
  }



  ngOnInit() {
    if (localStorage.getItem("currentUser")) {
      this.authService.loggedIn.next(true);
    }
  }

}