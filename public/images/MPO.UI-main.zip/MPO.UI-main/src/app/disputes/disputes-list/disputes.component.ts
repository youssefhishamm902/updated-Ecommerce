import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Table } from 'primeng/table';
import { MenuItem } from 'primeng/api';
import Jsona from 'jsona';
import { AppConfig } from 'src/app/app.config';
import { Subject } from 'rxjs';
import { DisputesServiceService } from 'src/app/disputes/shared/services/disputes.service';
import { SpinnerService } from 'src/core/services/spinner.service';

@Component({
  selector: 'app-disputes',
  templateUrl: './disputes.component.html',
  styleUrls: ['./disputes.component.scss'],
  providers: [DisputesServiceService],
})
export class DisputesComponent implements OnInit {
  @ViewChild('dt') table!: Table;
  @ViewChild('searchInput') searchInput!: ElementRef;
  @ViewChild('menuContainer', { static: true }) menuContainer!: ElementRef;
  public apiServer = AppConfig.settings.apiServer;
  public unsubscribe$ = new Subject();
  reportersIconsURL = this.apiServer.reportersIconsUrl;
  disputeIconsURl = this.apiServer.disputeIconsUrl;

  data = ([] = []);

  filteredData = [];
  filteredDataSolved = [];
  values: string[] | undefined;
  menuItems: MenuItem[] = [];
  showOptions = false;
  value: string = '';
  selectedRow: any;
  showMenu: boolean = false;
  selectedOption: string = '';
  selectedFilterOptions: string[] = [];
  currentBoard: string = '';
  currentClaimIdRow: string = '';
  currentClaimIdRowSolvedDispute: string = '';
  currentClaimIdRowChild: string = '';
  currentReportersIdRowChild: string = '';
  currentReportersIdRowSolvedDispute: string = '';
  currentReportItemIdChild: string = '';
  currentBoardSolved: string = '';
  currentPageIndexIsOpenDispute: number = 0;
  currentPageIndexIsSolvedDispute: number = 0;
  currentPageIndexRow: number = 0;
  currentPageIndexRowSolvedDispute: number = 0;
  currentPageIndexChildRowOfItem: number = 0;
  currentPageSizeIsOpenDispute: number = 5;
  currentPageSizeIsSolvedDispute: number = 5;
  currentPageSizeRow: number = 50;
  currentPageSizeRowSolvedDispute: number = 50;
  currentPageSizeChildRowOfItem: number = 999;
  currentSortIsOpenDispute: string = '';
  currentSortIsSolvedDispute: string = '';
  currentStatusesRow: string = 'Open,Unpublished';
  currentStatusesRowSolvedDispute: string = 'Open,Unpublished';
  currentStatusesIdRowChild: string = 'Disputes';
  currentStatusesChildRowOfItem: string = 'Disputes';
  currentStatusesChildRowOfItemSolvedDispute: string = 'Assigned';
  currentReportIdChildRowOfItem: string = '';
  totalItemsOfData: number = 0;
  totalItemsSolvedOfData: number = 0;
  searchQueryIsOpenDispute = '';
  searchQueryIsSolvedDispute = '';
  dropdownVisible: boolean = true;
  dropdownOpen = false;
  previousSortedBy: string = '';
  previousSortedBySolved: string = '';
  openDisputeTable: boolean = false;
  solvedDisputeTable: boolean = false;
  visible: boolean = false;
  checkradiobutton!: string;
  dataFormatter = new Jsona();
  currentFirstChildRowOfOpenDispute: any[] = [];
  currentReleasesChildRowOpenDispute: any[] = [];
  currentReleasesChildRowSolvedDispute: any[] = [];
  isExpanded: boolean = false;
  isExpandedChild: boolean = false;
  expandedRow: any = null;
  expandReleasesRow: any = null;
  constructor(
    private disputesService: DisputesServiceService,
    private spinnerService: SpinnerService
  ) {
    this.currentBoard = String(
      JSON.parse(localStorage.getItem('currentUser')!).board.id
    );
  }

  ngOnInit() {
    this.openDisputeTable = true;
    this.solvedDisputeTable = false;
   
    this.getDisputes(false);
    this.getDisputes(true);
  }

  getDisputes(isSolved: boolean) {
    this.spinnerService.show();
    this.disputesService
      .getDisputes(
        this.currentBoard,
        isSolved ? this.currentPageIndexIsSolvedDispute : this.currentPageIndexIsOpenDispute,
        isSolved ? this.currentPageSizeIsSolvedDispute : this.currentPageSizeIsOpenDispute,
        isSolved ? this.currentSortIsSolvedDispute : this.currentSortIsOpenDispute,
        isSolved ? this.searchQueryIsSolvedDispute : this.searchQueryIsOpenDispute,
        'OpenDispute',
        isSolved
      )
      .subscribe((response) => {
        if (isSolved) {
          this.filteredDataSolved = response.data;
          this.totalItemsSolvedOfData = response.meta.count;
        } else {
          this.filteredData = response.data;
          this.totalItemsOfData = response.meta.count;
        }
        this.spinnerService.hide();
      });
  }

  switchAndChangeTable(
    openDisputeTable: boolean,
    solvedDisputeTable: boolean,
    isSolved: boolean
  ): void {
    this.openDisputeTable = openDisputeTable;
    this.solvedDisputeTable = solvedDisputeTable;

    this.searchQueryIsOpenDispute = isSolved ? this.searchQueryIsSolvedDispute : '';
    this.currentPageIndexIsOpenDispute = isSolved ? this.currentPageIndexIsSolvedDispute : 0;

    this.getDisputes(isSolved);
  }

  onSort(event: any, isSolved: boolean): void {
    if (event && event.field) {
      let sortField = '';
      let sortOrder = '';

      switch (event.field) {
        case 'assignedTo':
          sortField = 'assignedTo';
          break;
        case 'disputes':
          sortField = 'disputes';
          break;
        case 'disputeDate':
          sortField = 'disputeDate';
          break;
        case 'sovledDispute':
          sortField = 'created';
          break;
        default:
          sortField = '-created';
      }

      if (event.order === 1) {
        sortOrder = 'asc';
      } else {
        sortOrder = 'desc';
        sortField = `-${sortField}`;
      }

      if (isSolved) {
        this.currentSortIsSolvedDispute = sortField;
        if (this.currentSortIsSolvedDispute === this.previousSortedBySolved) {
          return;
        }
        this.previousSortedBySolved = this.currentSortIsSolvedDispute;
      } else {
        this.currentSortIsOpenDispute = sortField;
        if (this.currentSortIsOpenDispute === this.previousSortedBy) {
          return;
        }
        this.previousSortedBy = this.currentSortIsOpenDispute;
      }

      this.getDisputes(isSolved);
    }
  }

  Search(event: any, isSolved: boolean): void {
    var searchQuery = event.target.value.trim();

    if (isSolved) {
      this.searchQueryIsSolvedDispute = searchQuery;
      this.currentPageIndexIsSolvedDispute = 0;
    } else {
      this.searchQueryIsOpenDispute = searchQuery;
      this.currentPageIndexIsOpenDispute = 0;
    }

    this.getDisputes(isSolved);
  }

  onPageChange(event: any, isSolved: boolean): void {
    if (isSolved) {
      this.currentPageIndexIsSolvedDispute = event.first;
      this.currentPageSizeIsSolvedDispute = event.rows;
    } else {
      this.currentPageIndexIsOpenDispute = event.first;
      this.currentPageSizeIsOpenDispute = event.rows;
    }

    this.getDisputes(isSolved);
  }

  openDisputes(): void {
    this.switchAndChangeTable(true, false, false);
  }

  solvedDisputes(): void {
    this.switchAndChangeTable(false, true, true);
  }
  showDialog(row: any) {
    this.selectedRow = row; // Assign the selected row data
    this.visible = true;
  }
  ///////
  expandFirstRowOpenDispute(data: any) {
    this.spinnerService.show();
    this.currentClaimIdRow = '';
    this.expandedRow = this.expandedRow === data ? null : data;
    this.currentClaimIdRow = data.ClaimId;
    this.disputesService
      .expandFirstRowOpenDispute(
        this.currentBoard,
        this.currentClaimIdRow,
        this.currentPageIndexRow,
        this.currentPageSizeRow,
        this.currentStatusesRow
      )
      .subscribe((response) => {
        this.currentFirstChildRowOfOpenDispute = response.data;
        this.isExpanded = !this.isExpanded;
        this.spinnerService.hide();
      });
  }
  expandReleasesChildRowOpenDispute(data: any, rowIndex: any) {
    this.currentClaimIdRowChild = '';
    this.expandReleasesRow = this.expandReleasesRow === data ? null : data;
    this.currentClaimIdRowChild = this.currentClaimIdRow;
    this.currentReportIdChildRowOfItem = this.currentFirstChildRowOfOpenDispute[rowIndex].Id;
    this.currentReportersIdRowChild = this.currentReportIdChildRowOfItem;

    this.expandItemRowOpenDispute().subscribe((response) => {
      this.currentReleasesChildRowOpenDispute = response.data;
      this.expandReleasesRowOpenDispute().subscribe((response) => {
        this.currentReleasesChildRowOpenDispute = response.data;
      });
      this.isExpandedChild = !this.isExpandedChild;
    });
  }

  expandItemRowOpenDispute() {
    return this.disputesService.expandItemRowOpenDispute(
      this.currentBoard,
      this.currentClaimIdRow,
      this.currentStatusesChildRowOfItem,
      this.currentPageIndexChildRowOfItem,
      this.currentPageSizeChildRowOfItem,
      this.currentReportIdChildRowOfItem
    );
  }

  expandReleasesRowOpenDispute() {
    return this.disputesService.expandReleasesRowOpenDispute(
      this.currentBoard,
      this.currentClaimIdRow,
      this.currentReportersIdRowChild,
      this.currentStatusesIdRowChild,
      this.currentReleasesChildRowOpenDispute[0].Id
    );
  }

  ////////////////////////////////////////////////////////////////////////////////
  expandFirstRowSolvedDispute(data: any) {
    this.currentClaimIdRow = '';
    this.expandedRow = this.expandedRow === data ? null : data;
    this.currentClaimIdRow = data.ClaimId;
    this.expandFirstRowSolvedDisputeRequest();
  }
  
  expandFirstRowSolvedDisputeRequest() {
    this.disputesService
      .expandFirstRowSolvedDispute(
        this.currentBoard,
        this.currentClaimIdRow,
        this.currentPageIndexRowSolvedDispute,
        this.currentPageSizeRowSolvedDispute,
        this.currentStatusesRowSolvedDispute
      )
      .subscribe((response) => {
        this.currentFirstChildRowOfOpenDispute = response.data;
        this.isExpanded = !this.isExpanded;
      });
  }
  
  expandReleasesChildRowSolvedDispute(data: any, rowIndex: any) {
    this.currentClaimIdRowSolvedDispute = '';
    this.expandReleasesRow = this.expandReleasesRow === data ? null : data;
    this.currentClaimIdRowSolvedDispute = this.currentClaimIdRow;
    this.currentReportIdChildRowOfItem = this.currentFirstChildRowOfOpenDispute[rowIndex].Id;
    this.currentReportersIdRowSolvedDispute = this.currentReportIdChildRowOfItem;
    this.expandItemRowOpenDisputeRequest().subscribe((response) => {
      this.currentReleasesChildRowSolvedDispute = response.data;
      this.expandItemRowSolvedDisputeRequest().subscribe((response) => {
        this.currentReleasesChildRowSolvedDispute = response.data;
        this.expandReleasesRowSolvedDisputeRequest().subscribe((response) => {
          this.currentReleasesChildRowSolvedDispute = response.data;
        });
        this.isExpandedChild = !this.isExpandedChild;
      });
    });
  }
  
  expandItemRowOpenDisputeRequest() {
    return this.disputesService.expandItemRowOpenDispute(
      this.currentBoard,
      this.currentClaimIdRowSolvedDispute,
      this.currentStatusesChildRowOfItemSolvedDispute,
      this.currentPageIndexChildRowOfItem,
      this.currentPageSizeChildRowOfItem,
      this.currentReportIdChildRowOfItem
    );
  }
  
  expandItemRowSolvedDisputeRequest() {
    return this.disputesService.expandItemRowOpenDispute(
      this.currentBoard,
      this.currentClaimIdRowSolvedDispute,
      this.currentStatusesChildRowOfItemSolvedDispute,
      this.currentPageIndexChildRowOfItem,
      this.currentPageSizeChildRowOfItem,
      this.currentReportIdChildRowOfItem
    );
  }
  
  expandReleasesRowSolvedDisputeRequest() {
    return this.disputesService.expandReleasesRowSolvedDispute(
      this.currentBoard,
      this.currentClaimIdRowSolvedDispute,
      this.currentReportersIdRowSolvedDispute,
      this.currentStatusesChildRowOfItemSolvedDispute,
      this.currentReleasesChildRowSolvedDispute[0].Id
    );
  }
  

}

