export interface Dispute {
  releaseName: string;
  artistNames: string;
  assignedTo: string;
  disputes: string;
  disputeDate: Date;
  ReleaseCover: string;
  Members: {
    LabelName: string;
  }[];
  ClaimId: number;
  currentFirstChildRowOfOpenDispute: {
    Reporter: {
      Id: string;
      Name: string;
    };
    Quarter: string;
    Year: number;
    SubTitle: string;
    Closing: Date;
  }[];
  currentReleasesChildRowOpenDispute: {
    TracksCount: number;
    Tracks: {
      TrackName: string;
      Isrc: string;
    }[];
  }[];
}
