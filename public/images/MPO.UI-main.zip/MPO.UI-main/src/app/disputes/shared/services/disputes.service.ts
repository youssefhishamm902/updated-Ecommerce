import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import Jsona from 'jsona';
import { AppConfig } from '../../../app.config';


@Injectable({
  providedIn: 'root', 
})
export class DisputesServiceService {
  protected apiServer = AppConfig.settings.apiServer;
  headers = new HttpHeaders();

  constructor(private http: HttpClient, private appConfig: AppConfig) {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!)
      .authenticated.access_token;
    this.headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
    });
  }

  getDisputes(
    boardId: string,
    pageIndex: number,
    pageSize: number,
    sortedBy: string = '-disputeDate',
    searchQuery: string,
    type: string = 'OpenDispute',
    isSolved: boolean = false
  ): Observable<any> {
    let options = { headers: this.headers };

    let sortParam = sortedBy ? `&sort=${sortedBy}` : `&sort=-disputeDate`;

    let searchQueryParam = searchQuery
      ? `&filter.search=${searchQuery}`
      : '&filter.search=';
    let typeParam = type ? `&type=${type}` : `&type=OpenDispute`;

    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/claims?boardId=${boardId}&page.limit=${pageSize}&page.offset=${pageIndex}${sortParam}${searchQueryParam}${typeParam}`;

    if (isSolved) {
      url = url.replace('OpenDispute', 'SovledDispute');
      url = url.replace('-disputeDate', '-created');
    }

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }
  expandFirstRowOpenDispute(
    boardIdRowOpenDispute: string,
    claimIdRowOpenDispute: string,
    pageIndexRowOpenDispute: number,
    pageSizeRowOpenDispute: number = 50,
    statusesByRowOpenDispute: string = 'Open,Unpublished'
  ): Observable<any> {
    let options = { headers: this.headers };

    let statusesParam = statusesByRowOpenDispute
      ? `&filter.statuses=${statusesByRowOpenDispute}`
      : `&filter.statuses=Open,Unpublished`;

    let claimParam = claimIdRowOpenDispute
      ? `&filter.claimIds=${claimIdRowOpenDispute}`
      : `&filter.claimIds=${claimIdRowOpenDispute}`;

    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports?boardId=${boardIdRowOpenDispute}&isCountersRequired=false&page.limit=${pageSizeRowOpenDispute}&page.offset=${pageIndexRowOpenDispute}${claimParam}${statusesParam}`;

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }
  expandFirstRowSolvedDispute(
    boardIdRowSolvedDispute: string,
    claimIdRowSolvedDispute: string,
    pageIndexRowSolvedDispute: number,
    pageSizeRowSolvedDispute: number = 50,
    statusesByRowSolvedDispute: string = 'Open,Unpublished'
  ): Observable<any> {
    let options = { headers: this.headers };

    let statusesParam = statusesByRowSolvedDispute
      ? `&filter.statuses=${statusesByRowSolvedDispute}`
      : `&filter.statuses=Open,Unpublished`;

    let claimParam = claimIdRowSolvedDispute
      ? `&filter.claimIds=${claimIdRowSolvedDispute}`
      : `&filter.claimIds=${claimIdRowSolvedDispute}`;

    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports?boardId=${boardIdRowSolvedDispute}&isCountersRequired=false&page.limit=${pageSizeRowSolvedDispute}&page.offset=${pageIndexRowSolvedDispute}${claimParam}${statusesParam}`;

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }
  expandItemRowOpenDispute(
    boardIdRowChild: string,
    claimIdRowChild: string,
    statusesIdByRow: string = 'Disputes',
    pageIndexRowItem: number,
    pageSizeRowItem: number = 999,
    reportItemId: string
  ): Observable<any> {
    let options = { headers: this.headers };

    let statusesIdParam = statusesIdByRow
      ? `&filter.status=${statusesIdByRow}`
      : `&filter.status=Disputes`;

    let claimIdParam = claimIdRowChild
      ? `&filter.claimIds=${claimIdRowChild}`
      : `&filter.claimIds=${claimIdRowChild}`;
    let reportParam = reportItemId ? `${reportItemId}` : `${reportItemId}`;
    let reportIdParam = reportItemId
      ? `&reportId=${reportItemId}`
      : `&reportId=${reportItemId}`;
    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports/${reportParam}/items?boardId=${boardIdRowChild}${claimIdParam}${statusesIdParam}&page.limit=${pageSizeRowItem}&page.offset=${pageIndexRowItem}${reportIdParam}`;

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }
  expandReleasesRowOpenDispute(
    boardIdRowChild: string,
    claimIdRowChild: string,
    reportersIdParam: string,
    statusesIdByRow: string = 'Disputes',
    reportItemId: string
  ): Observable<any> {

    let options = { headers: this.headers };

    let statusesIdParam = statusesIdByRow
      ? `&filter.status=${statusesIdByRow}`
      : `&filter.status=Disputes`;

    let claimIdParam = claimIdRowChild
      ? `&filter.claimIds=${claimIdRowChild}`
      : `&filter.claimIds=${claimIdRowChild}`;

    let reporterIdParam = reportItemId ? `${reportItemId}` : `${reportItemId}`;

    let reporterParam = reportersIdParam
      ? `&filter.reports=${reportersIdParam}`
      : `&filter.reports=${reportersIdParam}`;

    let reportItemParam = reportItemId
      ? `&reportItemId=${reportItemId}`
      : `&reportItemId=${reportItemId}`;

    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reportItems/${reporterIdParam}/releases?boardId=${boardIdRowChild}${claimIdParam}${reporterParam}${statusesIdParam}${reportItemParam}`;

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }

  expandItemRowSolvedDispute(
    boardIdRowChild: string,
    claimIdRowChild: string,
    statusesIdByRow: string = 'Assign',
    pageIndexRowItem: number,
    pageSizeRowItem: number = 999,
    reportItemId: string
  ): Observable<any> {
    let options = { headers: this.headers };

    let statusesIdParam = statusesIdByRow
      ? `&filter.status=${statusesIdByRow}`
      : `&filter.status=Assign`;

    let claimIdParam = claimIdRowChild
      ? `&filter.claimIds=${claimIdRowChild}`
      : `&filter.claimIds=${claimIdRowChild}`;
    let reportParam = reportItemId ? `${reportItemId}` : `${reportItemId}`;
    let reportIdParam = reportItemId
      ? `&reportId=${reportItemId}`
      : `&reportId=${reportItemId}`;
    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports/${reportParam}/items?boardId=${boardIdRowChild}${claimIdParam}${statusesIdParam}&page.limit=${pageSizeRowItem}&page.offset=${pageIndexRowItem}${reportIdParam}`;

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }
  expandReleasesRowSolvedDispute(
    boardIdRowChild: string,
    claimIdRowChild: string,
    reportersIdParam: string,
    statusesIdByRow: string = 'Disputes',
    reportItemId: string
  ): Observable<any> {

    let options = { headers: this.headers };

    let statusesIdParam = statusesIdByRow
      ? `&filter.status=${statusesIdByRow}`
      : `&filter.status=Disputes`;

    let claimIdParam = claimIdRowChild
      ? `&filter.claimIds=${claimIdRowChild}`
      : `&filter.claimIds=${claimIdRowChild}`;

    let reporterIdParam = reportItemId ? `${reportItemId}` : `${reportItemId}`;

    let reporterParam = reportersIdParam
      ? `&filter.reports=${reportersIdParam}`
      : `&filter.reports=${reportersIdParam}`;

    let reportItemParam = reportItemId
      ? `&reportItemId=${reportItemId}`
      : `&reportItemId=${reportItemId}`;

    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reportItems/${reporterIdParam}/releases?boardId=${boardIdRowChild}${claimIdParam}${reporterParam}${statusesIdParam}${reportItemParam}`;

    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }
}
