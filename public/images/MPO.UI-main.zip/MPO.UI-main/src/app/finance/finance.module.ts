import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FinanceComponent } from './finance/finance.component';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/components/shared.module';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { TreeTableModule } from 'primeng/treetable';
const routes: Routes = [
  {
    path: '',
    component: FinanceComponent
  }
];

@NgModule({
  declarations: [
    FinanceComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    SharedModule,
    TreeTableModule,
    TableModule,
    FormsModule,
    DropdownModule
  ]
})
export class FinanceModule { }
