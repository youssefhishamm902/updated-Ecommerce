import { Component, OnInit } from '@angular/core';
import { ReportItemsService } from './shared/services/report-items.service';
import { SpinnerService } from 'src/core/services/spinner.service';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { MessageService } from 'primeng/api';
import { AppConfig } from '../app.config';

@Component({
  selector: 'app-report-items',
  templateUrl: './report-items.component.html',
  styleUrls: ['./report-items.component.scss'],
})
export class ReportItemsComponent implements OnInit {
  data = ([] = []);

  UnassignedReportItems = false;
  DisputesReportItems = false;
  AssignedReportItems = true;
  SuggestedReportItems = false;

  filteredData = [];
  totalReportItemsOfData: number = 0;

  currentBoard: string = '';

  expandedRow: any = null;
  expandReleasesRow: any = null;
  expandedRowData: any;
  expandedChildRowData: any;
  currentFirstChildRowOfReportItems: any[] = [];
  currentReleasesChildRow: any[] = [];
  currentReleasesChildRowUnAssignReportItems: any[] = [];

  selectedRow: any;
  currentClaimIdRowChild: string = '';
  currentClaimIdRow: string = '';
  currentReportIdChildRowOfItem: string = '';
  currentReportersIdRowChild: string = '';

  currentPageIndex: number = 0;
  currentPageIndexIsUnAssignReportItems: number = 0;
  currentPageIndexIsAssignReportItems: number = 0;
  currentPageIndexIsSuggestedReportItems: number = 0;
  currentPageIndexIsDisputesReportItems: number = 0;

  currentPageSize: number = 5;
  currentPageSizeIsUnAssignReportItems: number = 5;
  currentPageSizeIsAssignReportItems: number = 5;
  currentPageSizeIsSuggestedReportItems: number = 5;
  currentPageSizeIsDisputesReportItems: number = 5;

  currentSort: string = '';
  currentSortIsUnAssignReportItems: string = '';
  currentSortIsAssignReportItems: string = '';
  currentSortIsSuggestedReportItems: string = '';
  currentSortIsDisputesReportItems: string = '';

  previousSortByUnAssign: string = '';
  previousSortByAssign: string = '';
  previousSortBySuggested: string = '';
  previousSortByDisputes: string = '';

  searchQuery: string = '';
  searchQueryIsAssignedReportItems: string = '';
  searchQueryIsDisputesReportItems: string = '';
  searchQueryIsUnassignedReportItems: string = '';
  searchQueryIsSuggestedReportItems: string = '';

  visible: boolean = false;
  visibleAssign: boolean = false;
  selectedOption: string = '';
  selectedOptionApi: string = '';
  selectedSearchOption: string = '';
  dropdownOptions: string[] = [];
  filterOptions: string[] = [
    'Report',
    'Artist',
    'Album',
    'Track',
    'ISRC',
    'UPC',
    'Suggested Label',
    'Period',
  ];
  FilterSearchQuery: string = '';
  RecommendedData = [];
  selectedFilters: any[] = [];
  UnknownRepertoire: any;
  DataToAssign: any[] = [];
  selectedAssign: any;
  DataToAssignSearchText: string = '';
  DataToAssignSearchResult: any[] = [];
  RowData: any;
  assignedCount: number = 0;
  unassignedCount: number = 0;
  autoassignedCount: number = 0;
  disputesCount: number = 0;
  type: string = 'Unassigned';
  failed: boolean = false;
  exportTimeout: number = AppConfig.settings.exportTimeout;

  constructor(
    private spinnerService: SpinnerService,
    private router: Router,
    private reportItemsService: ReportItemsService,
    private messageService: MessageService
  ) {
    this.currentBoard = String(
      JSON.parse(localStorage.getItem('currentUser')!).board.id
    );
  }
  ngOnInit(): void {
    this.getReportItems('Unassigned');
    this.AssignedReportItems = true;
    this.UnassignedReportItems = false;
    this.SuggestedReportItems = false;
    this.DisputesReportItems = false;
  }
  getReportItems(type: string) {
    this.spinnerService.show();
    switch (type) {
      case 'Unassigned':
        this.currentPageIndex = this.currentPageIndexIsUnAssignReportItems;
        this.currentPageSize = this.currentPageSizeIsUnAssignReportItems;
        this.currentSort = this.currentSortIsUnAssignReportItems;
        this.searchQuery = this.searchQueryIsUnassignedReportItems;
        break;
      case 'Assigned':
        this.currentPageIndex = this.currentPageIndexIsAssignReportItems;
        this.currentPageSize = this.currentPageSizeIsAssignReportItems;
        this.currentSort = this.currentSortIsAssignReportItems;
        this.searchQuery = this.searchQueryIsAssignedReportItems;
        break;
      case 'AutoAssigned':
        this.currentPageIndex = this.currentPageIndexIsSuggestedReportItems;
        this.currentPageSize = this.currentPageSizeIsSuggestedReportItems;
        this.currentSort = this.currentSortIsSuggestedReportItems;
        this.searchQuery = this.searchQueryIsSuggestedReportItems;
        break;
      case 'Disputes':
        this.currentPageIndex = this.currentPageIndexIsDisputesReportItems;
        this.currentPageSize = this.currentPageSizeIsDisputesReportItems;
        this.currentSort = this.currentSortIsDisputesReportItems;
        this.searchQuery = this.searchQueryIsDisputesReportItems;
        break;
    }

    this.reportItemsService
      .getReportItems(
        this.currentBoard,
        this.currentPageIndex,
        this.currentPageSize,
        this.currentSort,
        this.searchQuery,
        type,
        this.UnknownRepertoire
      )
      .subscribe({
        next: (response) => {
          this.filteredData = response.Data;
          this.totalReportItemsOfData = response.Meta.count;
          this.assignedCount = response.Meta.assigned;
          this.unassignedCount = response.Meta.unassigned;
          this.autoassignedCount = response.Meta.autoAssigned;
          this.disputesCount = response.Meta.disputes;
          this.spinnerService.hide();
        },
      });
  }
  Search(event: any, type: string) {
    var searchQuery = event.target.value.trim();
    switch (type) {
      case 'Unassigned':
        this.searchQueryIsUnassignedReportItems = searchQuery;
        this.currentPageIndexIsUnAssignReportItems = 0;
        break;
      case 'Assigned':
        this.searchQueryIsAssignedReportItems = searchQuery;
        this.currentPageIndexIsAssignReportItems = 0;
        break;
      case 'AutoAssigned':
        this.searchQueryIsSuggestedReportItems = searchQuery;
        this.currentPageIndexIsSuggestedReportItems = 0;
        break;
      case 'Disputes':
        this.searchQueryIsDisputesReportItems = searchQuery;
        this.currentPageIndexIsDisputesReportItems = 0;
        break;
    }
    this.getReportItems(type);
  }

  onSort(event: any, type: string) {
    if (event && event.field) {
      let sortField = '';
      let sortOrder = '';

      switch (event.field) {
        case 'assignedTo':
          sortField = 'label';
          break;
        case 'artist':
          sortField = 'artistName';
          break;
        case 'suggestedLabel':
          sortField = 'suggestedLabel';
          break;
        case 'label':
          sortField = 'suggestedLabel';
          break;
        case 'downloads':
          sortField = 'downloadsCount';
          break;
        case 'streams':
          sortField = 'streamsCount';
          break;
        case 'duration':
          sortField = 'durationSeconds';
          break;
      }
      if (event.order === 1) {
        sortOrder = 'asc';
        sortField = `-${sortField}`;
      } else {
        sortOrder = 'desc';
      }
      switch (type) {
        case 'Unassigned':
          this.currentSortIsUnAssignReportItems = sortField;
          if (
            this.currentSortIsUnAssignReportItems ===
            this.previousSortByUnAssign
          ) {
            return;
          }
          this.previousSortByUnAssign = this.currentSortIsUnAssignReportItems;
          break;
        case 'Assigned':
          this.currentSortIsAssignReportItems = sortField;
          if (
            this.currentSortIsAssignReportItems === this.previousSortByAssign
          ) {
            return;
          }
          this.previousSortByAssign = this.currentSortIsAssignReportItems;
          break;
        case 'AutoAssigned':
          this.currentSortIsSuggestedReportItems = sortField;
          if (
            this.currentSortIsSuggestedReportItems ===
            this.previousSortBySuggested
          ) {
            return;
          }
          this.previousSortBySuggested = this.currentSortIsSuggestedReportItems;
          break;
        case 'Disputes':
          this.currentSortIsDisputesReportItems = sortField;
          if (
            this.currentSortIsDisputesReportItems ===
            this.previousSortByDisputes
          ) {
            return;
          }
          this.previousSortByDisputes = this.currentSortIsDisputesReportItems;
          break;
      }
      this.getReportItems(type);
    }
  }
  showDialog() {
    this.visible = true;
  }

  expandFirstRowReportItems(data: any, type: string) {
    this.currentClaimIdRow = '';
    this.expandedRow = this.expandedRow === data ? null : data;

    this.currentClaimIdRow = data.ClaimId;
    if (this.expandedRowData === data) {
      this.expandedRowData = null;
      return;
    }
    this.expandedRowData = data;
    this.spinnerService.show();
    this.reportItemsService
      .expandFirstRowReportItems(this.currentBoard, type, data.Id)
      .subscribe((response) => {
        this.currentFirstChildRowOfReportItems = response.Data;
        this.spinnerService.hide();
      });
  }
  expandReleasesChildRowReportItems(data: any, rowIndex: any) {
    this.currentReleasesChildRow =
      this.currentFirstChildRowOfReportItems[rowIndex].Tracks;
    this.currentClaimIdRowChild = '';
    this.expandReleasesRow = this.expandReleasesRow === data ? null : data;
    this.currentClaimIdRowChild = this.currentClaimIdRow;
    this.currentReportIdChildRowOfItem =
      this.currentFirstChildRowOfReportItems[rowIndex].Id;
    this.currentReportersIdRowChild = this.currentReportIdChildRowOfItem;
    if (this.expandedChildRowData === data) {
      this.expandedChildRowData = null;
      return;
    }

    this.expandedChildRowData = data;
  }

  onPageChange(event: any, type: string) {
    switch (type) {
      case 'Unassigned':
        this.currentPageIndexIsUnAssignReportItems = event.first;
        this.currentPageSizeIsUnAssignReportItems = event.rows;
        break;
      case 'Assigned':
        this.currentPageIndexIsAssignReportItems = event.first;
        this.currentPageSizeIsAssignReportItems = event.rows;
        break;
      case 'AutoAssigned':
        this.currentPageIndexIsSuggestedReportItems = event.first;
        this.currentPageSizeIsSuggestedReportItems = event.rows;
        break;
      case 'Disputes':
        this.currentPageIndexIsDisputesReportItems = event.first;
        this.currentPageSizeIsDisputesReportItems = event.rows;
        break;
    }
    this.getReportItems(type);
  }
  handleTabChange(event: any) {
    const selectedTab = event.index;
    if (selectedTab == 0) {
      if (this.selectedFilters.length == 0) {
        this.getReportItems('Assigned');
        this.type = 'Assigned';
        this.AssignedReportItems = true;
        this.UnassignedReportItems = false;
        this.SuggestedReportItems = false;
        this.DisputesReportItems = false;
        console.log(this.UnknownRepertoire);
      } else {
        this.ApplyFilter('Assigned');
      }
    } else if (selectedTab == 1) {
      if (this.selectedFilters.length == 0) {
        this.getReportItems('AutoAssigned');
        this.type = 'AutoAssigned';
        this.AssignedReportItems = false;
        this.UnassignedReportItems = false;
        this.SuggestedReportItems = true;
        this.DisputesReportItems = false;
      } else {
        this.ApplyFilter('AutoAssigned');
      }
    } else if (selectedTab == 2) {
      if (this.selectedFilters.length == 0) {
        this.getReportItems('Unassigned');
        this.type = 'Unassigned';
        this.AssignedReportItems = false;
        this.UnassignedReportItems = true;
        this.SuggestedReportItems = false;
        this.DisputesReportItems = false;
      } else {
        this.ApplyFilter('Unassigned');
      }
    } else if (selectedTab == 3) {
      if (this.selectedFilters.length == 0) {
        this.getReportItems('Disputes');
        this.type = 'Disputes';
        this.AssignedReportItems = false;
        this.UnassignedReportItems = false;
        this.SuggestedReportItems = false;
        this.DisputesReportItems = true;
      } else {
        this.ApplyFilter('Disputes');
      }
    }
  }
  getFilteredData(event: any) {
    var searchQuery = event.target.value;
    switch (this.selectedOption) {
      case 'Report':
        this.selectedOptionApi = 'reports';
        break;
      case 'Artist':
        this.selectedOptionApi = 'artists';
        break;
      case 'Album':
        this.selectedOptionApi = 'albums';
        break;
      case 'Track':
        this.selectedOptionApi = 'tracks';
        break;
      case 'ISRC':
        this.selectedOptionApi = 'isrcs';
        break;
      case 'UPC':
        this.selectedOptionApi = 'upcs';
        break;
      case 'Suggested Label':
        this.selectedOptionApi = 'labels';
        break;
    }
    this.reportItemsService
      .getFilteredData(this.currentBoard, this.selectedOptionApi, searchQuery)
      .subscribe({
        next: (response) => {
          this.RecommendedData = response.Data;
          this.dropdownOptions = response.Data.map((item: any) => ({
            label: item.Value,
          }));
        },
      });
  }
  addFilter(event: any) {
    let selectedFilter = {
      filter: this.selectedOptionApi,
      search: event.label,
    };
    this.selectedFilters.push(selectedFilter);
    this.selectedSearchOption = '';
  }
  removeFilter(filter: any) {
    const index = this.selectedFilters.indexOf(filter);
    if (index !== -1) {
      this.selectedFilters.splice(index, 1);
    }
  }
  ApplyFilter(type: string = 'Unassigned') {
    this.spinnerService.show();
    this.reportItemsService
      .ApplyFilter(
        this.currentBoard,
        this.selectedFilters,
        type,
        this.currentPageIndex,
        this.currentPageSize,
        this.searchQuery
      )
      .subscribe({
        next: (response) => {
          this.filteredData = response.Data;
          this.totalReportItemsOfData = response.Meta.count;
          this.visible = false;
          this.spinnerService.hide();
        },
      });
  }
  GoToDisputes() {
    this.router.navigate(['/disputes']);
  }
  ShowUnknownRepertoire() {
    this.getReportItems('Assigned');
  }
  showAssignDialog(data: any) {
    this.selectedAssign = null;
    this.visibleAssign = true;
    this.RowData = data;
    this.reportItemsService.getDataToAssign().subscribe({
      next: (response) => {
        let res = response.data;
        let totalLen = response.meta.count;
        let i = 0;
        for (i = 0; i < response.data.length; i++) {
          this.DataToAssign[i] = {
            key: i,
            name: response.data[i]?.attributes.title,
            id: response.data[i]?.id,
          };
        }
        for (let j = 0; j < response.included.length; j++) {
          this.DataToAssign[i] = {
            key: i,
            name: response.included[j]?.attributes.title,
            id: response.included[j]?.id,
          };
          i++;
        }
        console.log(this.DataToAssign);
        this.DataToAssignSearchResult = this.DataToAssign;
      },
    });
  }
  DataToAssignSearch() {
    this.DataToAssignSearchResult = this.DataToAssign.filter((item) =>
      item.name
        .toLowerCase()
        .includes(this.DataToAssignSearchText.toLowerCase())
    );
  }

  Assign(RowData: any, selectedID: string, type: string) {
    // Call release API
    this.reportItemsService
      .ReleaseAPI(this.currentBoard, RowData.Id, type)
      .subscribe({
        next: (response) => {
          const observables = [];
          for (let i = 0; i < response.Data.length; i++) {
            const claimId = response.Data[i].ClaimId;
            // Call claim API
            const claimObservable = this.reportItemsService.ClaimAPI(
              this.currentBoard,
              claimId
            );
            observables.push(claimObservable);
          }
          // Combine observables using forkJoin
          forkJoin(observables).subscribe((claimResponses) => {
            for (let i = 0; i < claimResponses.length; i++) {
              const claimRes = claimResponses[i];
              const boardIds = [selectedID];
              const releaseId = claimRes.ReleaseId;
              const claimID = claimRes.Id;
              // Call patch API to assign
              this.reportItemsService
                .Assign(this.currentBoard, claimID, releaseId, boardIds)
                .subscribe({
                  next: (res) => {
                    this.getReportItems(type);
                    this.visibleAssign = false;
                  },
                });
            }
          });
        },
      });
  }
  Unassign(RowData: any, type: string) {
    // Call release API
    this.reportItemsService
      .ReleaseAPI(this.currentBoard, RowData.Id, type)
      .subscribe({
        next: (response) => {
          const observables = [];
          for (let i = 0; i < response.Data.length; i++) {
            const claimId = response.Data[i].ClaimId;
            // Call claim API
            const claimObservable = this.reportItemsService.ClaimAPI(
              this.currentBoard,
              claimId
            );
            observables.push(claimObservable);
          }
          // Combine observables using forkJoin
          forkJoin(observables).subscribe((claimResponses) => {
            for (let i = 0; i < claimResponses.length; i++) {
              const claimRes = claimResponses[i];
              const claimID = claimRes.Id;
              // Call patch API to assign
              this.reportItemsService
                .Unassign(this.currentBoard, claimID)
                .subscribe({
                  next: (res) => {
                    this.getReportItems(type);
                    this.visibleAssign = false;
                  },
                });
            }
          });
        },
      });
  }

  exportDataToExcel() {
    //call first api
    let JobId = '';
    this.reportItemsService
      .exportReport(
        this.currentBoard,
        this.type,
        this.currentPageIndex,
        this.currentPageSize
      )
      .subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'info',
            summary: 'Export Started',
            detail:
              'Export of Filtered report items have been started. Please do not leave this screen - you will be notified when export is done.',
          });
          JobId = response.Id;
          //call second api
          this.checkJobStatus(JobId);
        },
        error: (error: any) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Export Failed',
            detail: 'An error occurred while exporting data. Please try again.',
          });
        },
      });
  }

  checkJobStatus(JobId: string) {
    this.reportItemsService
      .getBackgroundJob(JobId, this.currentBoard)
      .subscribe({
        next: (response) => {
          if (response.Status === 'Passed' && response.Result != null) {
            const exportUri = response.Result.ExportedReportUri;
            window.open(exportUri, '_blank');
            this.messageService.add({
              severity: 'success',
              summary: 'Export Finished',
              detail: 'Filtered report items are exported successfully!',
            });
          } else {
            if (!this.failed) {
              setTimeout(() => {
                this.checkJobStatus(JobId);
              }, this.exportTimeout);
            }
          }
        },
        error: (error: any) => {
          this.failed = true;
          this.messageService.add({
            severity: 'error',
            summary: 'Export Failed',
            detail: 'An error occurred while exporting data. Please try again.',
          });
        },
      });
  }
}
