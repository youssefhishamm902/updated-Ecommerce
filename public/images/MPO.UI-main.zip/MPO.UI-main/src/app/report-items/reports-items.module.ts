import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReportItemsComponent } from './report-items.component';
import { SharedModule } from '../../shared/components/shared.module';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { CheckboxModule } from 'primeng/checkbox';
import { ChipsModule } from 'primeng/chips';
import { MultiSelectModule } from 'primeng/multiselect';
import { PaginatorModule } from 'primeng/paginator';
import { MenuModule } from 'primeng/menu';
import { MenubarModule } from 'primeng/menubar';
import { ToastModule } from 'primeng/toast';
import { DropdownModule } from 'primeng/dropdown';
import { ToolbarModule } from 'primeng/toolbar';
import { DialogService } from 'primeng/dynamicdialog';
import { DialogModule } from 'primeng/dialog';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { RadioButtonModule } from 'primeng/radiobutton';

const myroutes: Routes = [
  {
    path: '', component: ReportItemsComponent
  },
];

@NgModule({
  declarations: [
    ReportItemsComponent,
  ],
  providers: [DialogService],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ToolbarModule,
    ReactiveFormsModule,
    RouterModule.forChild(myroutes),
    TableModule,
    MultiSelectModule,
    PaginatorModule,
    ChipsModule,
    CheckboxModule,
    MenubarModule,
    ReactiveFormsModule,
    DropdownModule,
    ToastModule,
    MenuModule,
    SharedModule,
    TableModule,
    DialogModule,
    PanelModule,
    TabViewModule,
    AutoCompleteModule,
    RadioButtonModule,
  ],
})
export class ReportItemsModule {}
