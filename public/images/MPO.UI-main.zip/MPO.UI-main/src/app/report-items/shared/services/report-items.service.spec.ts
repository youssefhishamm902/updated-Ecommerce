import { TestBed } from '@angular/core/testing';

import { ReportItemsService } from './report-items.service';

describe('ReportItemsService', () => {
  let service: ReportItemsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReportItemsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
