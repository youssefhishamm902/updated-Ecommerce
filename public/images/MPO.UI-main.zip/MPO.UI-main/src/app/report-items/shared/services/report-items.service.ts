import { Injectable } from '@angular/core';
import { AppConfig } from '../../../app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import Jsona from 'jsona';
import { map } from 'rxjs/operators';

const dataFormatter = new Jsona();
@Injectable({
  providedIn: 'root',
})
export class ReportItemsService {
  protected apiServer = AppConfig.settings.apiServer;
  headers = new HttpHeaders();

  constructor(private http: HttpClient, private appConfig: AppConfig) {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!)
      .authenticated.access_token;
    this.headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
    });
  }
  getReportItems(
    boardId: string,
    pageIndex: number,
    pageSize: number,
    sortedBy: string = '-suggestedLabel',
    searchQuery: string,
    type: string = 'Assigned',
    UnknownRepertoire: boolean = false
  ): Observable<any> {
    let options = { headers: this.headers };
    let sortParam = sortedBy ? `&sort=${sortedBy}` : ``;
    let searchQueryParam = searchQuery ? `&filter.search=${searchQuery}` : '';
    let typeParam = type ? `&filter.status=${type}` : `&filter.status=Assigned`;
    let url;
    if (type == 'Assigned' && UnknownRepertoire) {
      url =
        this.apiServer.metafireSuiteAPI +
        `/api/reports/all/items?boardId=${boardId}&filter.from=&filter.reporterId=b77fef25-d7e5-4f82-9e71-f3472fdb941a${typeParam}&filter.to=&filter.unknownRepertoire=${UnknownRepertoire}&page.limit=${pageSize}&page.offset=${pageIndex}${searchQueryParam}${sortParam}`;
    } else {
      url =
        this.apiServer.metafireSuiteAPI +
        `/api/reports/all/items?boardId=${boardId}&filter.from=&filter.reporterId=${typeParam}&filter.to=&filter.unknownRepertoire=&page.limit=${pageSize}&page.offset=${pageIndex}${searchQueryParam}${sortParam}`;
    }
    return this.http.get(url, options);
  }
  expandFirstRowReportItems(
    boardIdRowReportItems: string,
    type: string = 'Unassigned',
    reportItemId: string
  ): Observable<any> {
    let options = { headers: this.headers };
    let typeParam = type ? `&filter.status=${type}` : `&filter.status=Assigned`;
    var url =
      this.apiServer.metafireSuiteAPI +
      `/api/reportItems/${reportItemId}/releases?boardId=${boardIdRowReportItems}${typeParam}&reportItemId=${reportItemId}`;
    return this.http.get(url, options);
  }

  getFilteredData(
    boardId: string,
    selectedOption: string,
    searchQuery: string
  ): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/lookup/${selectedOption}?boardId=${boardId}&filter.search=${searchQuery}`;
    return this.http.get(url, options);
  }
  ApplyFilter(
    boardId: string,
    selectedFilters: any[],
    type: string = 'Assigned',
    pageIndex: number,
    pageSize: number,
    searchQuery: string
  ): Observable<any> {
    let options = { headers: this.headers };
    let selectedFiltersParams: string = '';
    selectedFilters.map((item) => {
      selectedFiltersParams += `&filter.${item.filter}=${item.search}`;
    });
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports/all/items?boardId=${boardId}${selectedFiltersParams}&filter.from=&filter.reporterId=&filter.search=${searchQuery}&filter.status=${type}&filter.to=&filter.unknownRepertoire=&page.limit=${pageSize}&page.offset=${pageIndex}`;
    return this.http.get(url, options);
  }
  //see again
  getDataToAssign(): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.authAPI +
      `/boards?filter[productType]=MetafireSuite&filter.excludeRootBoard=true&page%5Bnumber%5D=0&page%5Bsize%5D=1000&sort=title`;

    return this.http.get(url, options);
  }
  ReleaseAPI(boardId: string, itemId: string, type: string): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/reportItems/${itemId}/releases?boardId=${boardId}&filter.status=${type}&reportItemId=${itemId}`;
    return this.http.get(url, options);
  }
  ClaimAPI(boardId: string, ClaimId: string): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/claims/${ClaimId}?boardId=${boardId}`;
    return this.http.get(url, options);
  }
  Assign(
    boardId: string,
    ClaimId: string,
    ReleaseId: string,
    BoardIds: any
  ): Observable<any> {
    let options = { headers: this.headers };
    let body = {
      id: ClaimId,
      releaseId: ReleaseId,
      boardIds: BoardIds,
    };
    let url =
      this.apiServer.metafireSuiteAPI + `/api/claims?boardId=${boardId}`;
    return this.http.patch(url, body, options);
  }
  Unassign(boardId: string, ClaimId: string): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/claims/${ClaimId}?boardId=${boardId}`;
    return this.http.delete(url, options);
  }

  exportReport(
    boardId: string,
    type: string = 'Unassigned',
    pageIndex: number,
    pageSize: number
  ): Observable<any> {
    let options = {
      headers: this.headers,
      responseType: 'json' as 'blob', // Change responseType to 'json'
    };
    const url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports/all/export?boardId=${boardId}&filter.offset=${pageIndex}&filter.limit=${pageSize}&filter.status=${type}`;
    return this.http.get(url, options);
  }

  getBackgroundJob(backGroundId: string, boardId: string): Observable<any> {
    let options = { headers: this.headers };
    const url =
      this.apiServer.metafireSuiteAPI +
      `/api/background-jobs/${backGroundId}?boardId=${boardId}`;
    return this.http.get(url, options);
  }
}
