import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-report',
  templateUrl: './edit-report.component.html',
  styleUrls: ['./edit-report.component.scss']
})
export class EditReportComponent implements OnInit {

  reportdetailsvisible: boolean = false;

  constructor( private router: Router){}

  ngOnInit(): void {
    this.showDialogReport();
  }

  showDialogReport() {
    this.reportdetailsvisible = true;
  }

  closeDialog(){
    this.reportdetailsvisible=false;
    this.router.navigate(['/reports']);
  }
}
