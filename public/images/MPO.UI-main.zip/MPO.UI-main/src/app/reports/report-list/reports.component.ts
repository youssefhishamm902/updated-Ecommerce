import { Router } from '@angular/router';
import { Dialog } from 'primeng/dialog';
import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Renderer2,
} from '@angular/core';
import { Table } from 'primeng/table';
import { MenuItem, SelectItem } from 'primeng/api';
import { MessageService } from 'primeng/api';
import { ReportsService } from '../shared/services/reports.service';
import Jsona from 'jsona';
import { AppConfig } from 'src/app/app.config';
import { Subject, interval } from 'rxjs';
import { finalize, last, switchMap, takeWhile } from 'rxjs/operators';
import { DialogService } from 'primeng/dynamicdialog';
import { SpinnerService } from 'src/core/services/spinner.service';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
  providers: [ReportsService, DialogService],
})
export class ReportsComponent implements OnInit {
  @ViewChild('dt') table!: Table;
  @ViewChild('searchInput') searchInput!: ElementRef;
  @ViewChild('menuContainer', { static: true }) menuContainer!: ElementRef;
  @ViewChild('deleteDialog') deleteDialog!: Dialog;
  @ViewChild('menu') menu: any;
  @ViewChild('icon') icon!: ElementRef<any>;
  public apiServer = AppConfig.settings.apiServer;
  public unsubscribe$ = new Subject();
  reportersIconsURL = this.apiServer.reportersIconsUrl;
  filteredData = [];
  values: string[] | undefined;
  menuItems: MenuItem[] = [];
  showOptions = false;
  value: string = '';
  showMenu: boolean = false;
  statusOptions: SelectItem[] = [
    { label: 'Open', value: 'Open' },
    { label: 'Closed', value: 'Closed' },
    { label: 'Uploading', value: 'Uploading' },
    { label: 'Scanning', value: 'Scanning' },
    { label: 'Unpublished', value: 'Unpublished' },
    { label: 'Failed', value: 'Failed' },
  ];
  currentEditReportId: string = '';

  data: any[] = [];
  selectedOption: SelectItem = { label: '', value: '' };
  selectedFilterOptions: string[] = [];
  currentBoard: string = '';
  currentPageIndex: number = 0;
  currentPageSize: number = 5;
  currentSortedBy: string = '';
  totalNumberOfData: number = 0;
  searchQuery = '';
  dropdownVisible: boolean = true;
  dropdownOpen = false;
  selectedReport: any;
  displayDeleteDialog: boolean = false;
  showError: boolean = false;
  previousSortedBy: string = '';
  isInputValid: boolean = false;
  currentDeleteReportId: string = '';
  dataFormatter = new Jsona();
  @ViewChild('dialog', { static: false }) dialoge!: Dialog;
  items: MenuItem[] | undefined;

  exportProcessedReport: boolean = false;
  deleteDialogVisible: boolean = false;
  isDeleting: boolean = false;
  visible: boolean = false;
  reportId: string = '';
  currentOpenMenu: any = null;
  constructor(
    private router: Router,
    private reportsService: ReportsService,
    private spinnerService: SpinnerService,
    private messageService: MessageService
  ) {
    this.currentBoard = String(
      JSON.parse(localStorage.getItem('currentUser')!).board.id
    );
  }

  ngOnInit(): void {
    this.getReports();
  }

  showDialog() {
    this.visible = true;
  }

  routing() {
    this.router.navigate(['/reports/upload-report']);
  }
  getReports() {
    this.spinnerService.show();
    this.reportsService
      .getReports(
        this.currentBoard,
        this.currentPageIndex,
        this.currentPageSize,
        this.currentSortedBy,
        this.searchQuery,
        this.selectedFilterOptions
      )
      .subscribe((response) => {
        this.filteredData = [];
        this.filteredData = response.data;
        this.totalNumberOfData = response.meta.count;
        this.spinnerService.hide();
      });
  }
  getMenuItems(currentRow: any, status: string): MenuItem[] {
    if (status === 'Unpublished') {
      return [
        {
          label: 'Edit report details',
          icon: 'pi pi-pencil',
          command: () => this.editReportDetails(currentRow),
        },
        { label: 'Edit report items', icon: 'pi pi-file-edit' },
        { separator: true },
        {
          label: 'Export report',
          icon: 'pi pi-file-export',
          command: () => {
            this.exportReport(currentRow);
          },
        },
        { label: 'Publish report', icon: 'pi pi-cloud-upload' },
        { separator: true },
        {
          label: 'Delete report',
          icon: 'pi pi-trash',
          command: () => {
            this.openDeleteDialog(currentRow);
          },
        },
      ];
    } else if (status === 'Open') {
      return [
        { label: 'Edit report details', icon: 'pi pi-pencil' },
        { separator: true },
        {
          label: 'Export report',
          icon: 'pi pi-file-export',
          command: () => {
            this.exportReport(currentRow);
          },
        },
        { label: 'Process report', icon: 'pi pi-cog' },
        { label: 'Close report', icon: 'pi pi-times-circle' },
        { separator: true },
        {
          label: 'Delete report',
          icon: 'pi pi-trash',
          command: () => {
            this.openDeleteDialog(currentRow);
          },
        },
      ];
    } else if (status === 'Closed') {
      return [
        {
          label: 'Export report',
          icon: 'pi pi-file-export',
          command: () => {
            this.exportReport(currentRow);
          },
        },
        { separator: true },
        {
          label: 'Delete report',
          icon: 'pi pi-trash',
          command: () => {
            this.openDeleteDialog(currentRow);
          },
        },
      ];
    } else if (status === 'Failed') {
      return [
        {
          label: 'Delete report',
          icon: 'pi pi-trash',
          command: () => {
            this.openDeleteDialog(currentRow);
          },
        },
      ];
    } else {
      return [];
    }
  }
  editReportDetails(currentRow: any) {
    this.currentEditReportId = currentRow.Id;
    this.router.navigate(['reports/edit-report/', currentRow.Id]);
  }
  deleteReport() {
    const deleteReportId = this.selectedReport.Id;
    const boardId = this.currentBoard;
    this.spinnerService.show();
    this.reportsService
      .deleteReport(boardId, deleteReportId)
      .pipe(finalize(() => this.closeDeleteDialog()))
      .subscribe({
        next: (message) => {
          this.router
            .navigateByUrl('/', { skipLocationChange: true })
            .then(() => {
              this.router.navigate(['/reports']);
            });
          this.spinnerService.hide();
        },
        error: (error) => {
          this.spinnerService.hide();
        },
      });
  }

  private showMessage(message: string): void {
    alert(message);
  }
  openDeleteDialog(report: any) {
    this.selectedReport = report;
    this.displayDeleteDialog = true;
  }
  checkInputContent() {
    const reporterNameValues = `${this.selectedReport?.Reporter?.Name}.${
      this.selectedReport?.Quarter ? '' + this.selectedReport.Quarter : 'Annual'
    }.${this.selectedReport?.Year}`;
    this.isInputValid = this.value === reporterNameValues;
    this.showError = !this.isInputValid && this.value !== '';
  }
  closeDeleteDialog() {
    this.displayDeleteDialog = false;
  }

  showMenuToggle(report: any, event: Event, menu: any): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.currentOpenMenu && this.currentOpenMenu !== menu) {
      this.currentOpenMenu.hide();
    }
    menu.toggle(event.currentTarget);

    if (menu.visible) {
      this.currentOpenMenu = menu;
      document.addEventListener('click', this.hideMenuOnClick.bind(this));
      const exportMenuItem = menu.model.find(
        (item: MenuItem) => item.label === 'Export report'
      );
      if (exportMenuItem) {
        exportMenuItem.command = () => {
          this.exportReport(report);
          menu.hide();
        };
      }
      const deleteMenuItem = menu.model.find(
        (item: MenuItem) => item.label === 'Delete report'
      );
      if (deleteMenuItem) {
        deleteMenuItem.command = () => {
          this.delete();
          menu.hide();
        };
      }
    } else {
      document.removeEventListener('click', this.hideMenuOnClick.bind(this));
    }
  }

  hideMenuOnClick(): void {
    if (this.currentOpenMenu) {
      this.currentOpenMenu.hide();
      this.currentOpenMenu = null;
    }
  }

  exportReport(report: any): void {
    this.reportId = report.Id;
    this.currentBoard;
    this.exportProcessedReport = false;

    this.reportsService
      .exportReport(
        this.reportId,
        this.currentBoard,
        this.exportProcessedReport
      )
      .subscribe({
        next: (jobId: string) => {
          this.checkJobStatus(jobId);
        },
        error: (error: any) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Export Failed',
            detail: 'An error occurred while exporting data. Please try again.',
          });
        },
      });
  }

  checkJobStatus(jobId: string): void {
    this.reportsService.getBackgroundJob(jobId, this.currentBoard).subscribe({
      next: (secondResponse: any) => {
        if (this.isConditionStatus(secondResponse)) {
          const exportedReportUri = secondResponse.Result.ExportedReportUri;
          this.downloadExcelFile(exportedReportUri);
        } else {
          setTimeout(() => {
            this.checkJobStatus(jobId);
          }, 3000);
        }
      },
      error: (error: any) => {
        this.messageService.add({
          severity: 'error',
          summary: 'Export Failed',
          detail: 'An error occurred while exporting data. Please try again.',
        });
      },
      complete: () => {
        this.messageService.add({
          severity: 'Completed',
          summary: 'Export Successful',
          detail:
            'Export have been started. Please do not leave this screen - you will be notified when export is done',
        });
      },
    });
  }

  downloadExcelFile(exportedReportUri: string): void {
    window.open(exportedReportUri, '_blank');
  }

  isConditionStatus(response: any): boolean {
    return response && response.Status === 'Passed' && response.Result != null;
  }

  delete(): void {
    this.deleteDialogVisible = true;
  }
  onSort(event: any) {
    if (event && event.field) {
      let sortField = '';
      let sortOrder = '';

      switch (event.field) {
        case 'reportName':
          sortField = 'reportTitle';
          break;
        case 'uploadDate':
          sortField = 'created';
          break;
        case 'closingDate':
          sortField = 'closing';
          break;
        case 'assigned':
          sortField = 'assignedItems';
          break;
        case 'unassigned':
          sortField = 'unassignedItems';
          break;
        case 'disputes':
          sortField = 'disputedItems';
          break;
        case 'status':
          sortField = 'status';
          break;
        default:
          sortField = 'name';
      }

      if (event.order === 1) {
        sortOrder = 'asc';
        this.currentSortedBy = sortField;
      } else {
        sortOrder = 'desc';
        this.currentSortedBy = `-${sortField}`;
      }

      if (this.currentSortedBy === this.previousSortedBy) {
        return;
      }

      this.previousSortedBy = this.currentSortedBy;

      this.getReports();
    }
  }

  filterData(event: any): void {
    this.searchQuery = event.target.value.trim();
    this.currentPageIndex = 0;
    this.getReports();
  }

  closeSelectedOption(index: number): void {
    this.selectedFilterOptions.splice(index, 1)[0];
    this.getReports();
  }

  onFilterChange(event: any): void {
    const index = this.selectedFilterOptions.indexOf(event.value);
    if (index === -1) {
      this.selectedFilterOptions.push(event.value);
      this.reportsService
        .getReports(
          this.currentBoard,
          this.currentPageIndex,
          this.currentPageSize,
          this.currentSortedBy,
          this.searchQuery,
          this.selectedFilterOptions.map((x) => {
            return x.replace('Scanning', 'Processing');
          })
        )
        .subscribe((response) => {
          this.filteredData = response.data;
          this.totalNumberOfData = response.meta.count;
        });
    }
  }
  onPageChange(event: any) {
    this.currentPageIndex = event.first;
    this.currentPageSize = event.rows;
    this.getReports();
  }
}
