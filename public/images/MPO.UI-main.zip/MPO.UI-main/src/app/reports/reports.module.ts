import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportsComponent } from './report-list/reports.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/components/shared.module';
import { ReportDetailsComponent } from './upload-report/report-details/report-details.component';
import { UploadReportStepComponent } from './upload-report/upload-report-step/upload-report-step.component';
import { MatchingColumnsComponent } from './upload-report/matching-columns/matching-columns.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { CheckboxModule } from 'primeng/checkbox';
import { ChipsModule } from 'primeng/chips';
import { MultiSelectModule } from 'primeng/multiselect';
import { PaginatorModule } from 'primeng/paginator';
import { MenuModule } from 'primeng/menu';
import { MenubarModule } from 'primeng/menubar';
import { ToastModule } from 'primeng/toast';
import { DropdownModule } from 'primeng/dropdown';
import { ToolbarModule } from 'primeng/toolbar';
import { DialogService } from 'primeng/dynamicdialog';
import { UploadReportComponent } from './upload-report/upload-report.component';
import { EditReportComponent } from './report-list/edit-report/edit-report.component';
import { DialogModule } from 'primeng/dialog';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { DisputesComponent } from '../disputes/disputes-list/disputes.component';
import { RadioButtonModule } from 'primeng/radiobutton';

const myroutes: Routes = [
  {
    path: '', component: ReportsComponent
  },
  {
    path:'edit-report/:id', component:EditReportComponent,
  },
  {
    path:'upload-report', component:UploadReportComponent,
    children: [
      { path: '', redirectTo: 'Stepone', pathMatch: 'full' },
      { path: 'Stepone', component: ReportDetailsComponent },
     // { path: 'editReport/:id', component: ReportDetailsComponent },
      { path: 'Steptwo', component: UploadReportStepComponent },
      { path: 'Stepthree', component: MatchingColumnsComponent },
    ],
  },
  {
    path: 'disputes',
    component: DisputesComponent,
  },
];

@NgModule({
  declarations: [
    ReportsComponent,
    ReportDetailsComponent,
    UploadReportStepComponent,
    MatchingColumnsComponent,
    UploadReportComponent,
    EditReportComponent,
    MatchingColumnsComponent,
  ],
  providers: [DialogService],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ToolbarModule,
    ReactiveFormsModule,
    RouterModule.forChild(myroutes),
    TableModule,
    MultiSelectModule,
    PaginatorModule,
    ChipsModule,
    CheckboxModule,
    MenubarModule,
    ReactiveFormsModule,
    DropdownModule,
    ToastModule,
    MenuModule,
    SharedModule,
    TableModule,
    DialogModule,
    PanelModule,
    TabViewModule,
    AutoCompleteModule,
    RadioButtonModule,
  ],
})
export class ReportsModule {}
