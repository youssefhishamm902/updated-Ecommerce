export interface Base {
  id: number
}
