export interface Form03 {
  name: string;
  value: string;
}
