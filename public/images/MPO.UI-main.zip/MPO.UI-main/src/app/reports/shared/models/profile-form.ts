export interface ProfileForm {
  'FirstName': string,
  'LastName': string,
  'Email': string,
  'PhoneNumber': string,
  'JobTitle': string,
  'hasImage'?: boolean
}
