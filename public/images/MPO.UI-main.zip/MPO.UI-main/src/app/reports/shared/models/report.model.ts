import { Reporter } from "./reporter.model";

export interface Report {
    id: number;
    subTitle: string;
    quarter: string;
    year:number;
    closing:Date;
    reporterId:number;
    reporter:Reporter;
  }