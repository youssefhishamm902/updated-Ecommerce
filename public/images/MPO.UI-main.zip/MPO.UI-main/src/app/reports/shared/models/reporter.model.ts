export interface Reporter {
    id: number;
    type: string;
    name:string;
    hasImage:boolean;
  }