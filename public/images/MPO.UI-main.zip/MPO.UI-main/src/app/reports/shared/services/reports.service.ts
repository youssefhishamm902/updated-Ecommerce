import { Injectable } from '@angular/core';
import { FileUpload } from 'primeng/fileupload';
import { Subject } from 'rxjs';
import { Form03 } from '../models/form03';
import { Router } from '@angular/router';
import { AppConfig } from '../../../app.config';
import { Observable, throwError, of  } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';

import Jsona from 'jsona';
import { Reporter } from '../models/reporter.model';
const dataFormatter = new Jsona();
@Injectable({
  providedIn: 'root',
})
export class ReportsService {
  headers = new HttpHeaders();
  dropdown!: any[];
  headers01!: HttpHeaders;
  headers02!: HttpHeaders;
  headers03!: HttpHeaders;
  protected apiServer = AppConfig.settings.apiServer;

  // ProfileImage: Subject<any> = new Subject<any>();
  response01: Subject<any> = new Subject<any>();
  response03: Subject<any> = new Subject<any>();

  close: Subject<any> = new Subject<any>();

  token: any = JSON.parse(localStorage.getItem('currentUser')!);
  accessToken = this.token.authenticated.access_token;

  form01!: any;
  reportLink!: URL;
  form03!: Form03[];

  constructor(private http: HttpClient, private router: Router) {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!)
      .authenticated.access_token;
    this.headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
    });

    this.headers01 = new HttpHeaders({
      Authorization: `Bearer ${this.accessToken}`,
      'Content-Type': 'application/vnd.api+json',
    });

    this.headers02 = new HttpHeaders({
      Authorization: `Bearer ${this.accessToken}`,
      'Content-Type':
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });

    this.headers03 = new HttpHeaders({
      Authorization: `Bearer ${this.accessToken}`,
      'Content-Type': 'application/vnd.api+json',
    });
  }

  UploadFile(uploadedFile: FileUpload) {
    return this.http
      .post(
        this.apiServer.metafireSuiteAPI +
          `/api/upload?boardId=${this.token.board.id}`,
        uploadedFile,
        { headers: this.headers02 }
      )
      .subscribe((res: any) => {
        this.reportLink = res.ReportLink;
        this.dropdown = res.Headers;
      });
  }

  getReporters() {
    return this.http.get<Reporter[]>(
      this.apiServer.reportServiceUrl +
        `/reporter?organizationId=${this.token.board.organisation.id}`, { headers: this.headers }
    );
  }

  SaveReport() {
    return this.http.post(
      this.apiServer.metafireSuiteAPI +
        `/api/reports?boardId=${this.token.board.id}`,
      {
        mapping: {
          isrc: this.form03[4].value,
          artistTitle: this.form03[2].value,
          trackTitle: this.form03[0].value,
          albumTitle: this.form03[1].value,
          durationTitle: this.form03[6].value,
          streamsTitle: this.form03[8].value,
          downloadsTitle: this.form03[7].value,
          labelTitle: this.form03[5].value,
          upc: this.form03[3].value,
        },
        subTitle: this.form01.subtitle,
        year: this.form01.year,
        closing: this.form01.date,
        reportFileUri: this.reportLink,
        reporter: {
          id: this.form01.reporter.id,
        },
      },
      { headers: this.headers03 }
    );
  }

  getReports(
    boardId: string,
    pageIndex: number,
    pageSize: number,
    sortedBy: string = '-name',
    searchQuery: string,
    selectedStatuses: string[]
  ): Observable<any> {
    let options = { headers: this.headers };
    let sortParam = sortedBy ? `&sort=${sortedBy}` : `&sort=-name`;
    let statusParams = selectedStatuses
      .map((status) => `&filter.statuses=${status}`)
      .join('');
    let searchQueryParam = searchQuery
      ? `&filter.searchquery=${searchQuery}`
      : '&filter.searchquery=';
      // let url = this.apiServer.metafireSuiteAPI +`/api/claims?boardId=${boardId}&page.limit=${pageSize}&page.offset=${pageIndex}${sortParam}${searchQueryParam}${typeParam}`;
      let url = this.apiServer.metafireSuiteAPI +`/api/reports?boardId=${boardId}&isCountersRequired=true&includeCounters=true&page.limit=${pageSize}&page.offset=${pageIndex}${sortParam}${statusParams}${searchQueryParam}`;
    return this.http.get(url, options).pipe(
      map((response: any) => {
        return {
          data: response.Data,
          meta: response.Meta,
        };
      })
    );
  }

  deleteReport(boardId: string, deleteReportId: string): Observable<string> {
    const options = { headers: this.headers };
    const url = `${this.apiServer.metafireSuiteAPI}/api/reports/${deleteReportId}?boardId=${boardId}`;

    return this.http.delete(url, options).pipe(
      map(() => 'Report deleted successfully'),
      catchError(() => of('Error deleting report'))
    );
  }

  getReportDetails(boardId: string, editReportId: string): Observable<any> {
    let options = { headers: this.headers };
    //let editReportIdMenu = editReportId ? `${editReportId}` : `${editReportId}`;
let url = this.apiServer.reportServiceUrl +`/report/${editReportId}?boardId=${boardId}`;
    return this.http.get(url, options);
  }

  saveEditReport(boardId: string, editReportId: number, editedReportDetails: any): Observable<any> {
    let options = { headers: this.headers };
    let url = this.apiServer.metafireSuiteAPI +`/api/reports/${editReportId}?boardId=${boardId}`;
    return this.http.patch(url, editedReportDetails,  options);
  }
 
  exportReport(reportId: string, boardId: string, exportProcessedReport: boolean): Observable<any> {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!).authenticated.access_token;
    this.headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
    });
    let options = {
      headers: this.headers,
      responseType: 'json' as 'blob', // Change responseType to 'json'
    };
    const url =this.apiServer.metafireSuiteAPI +  `/api/reports/${reportId}/export?boardId=${boardId}&exportProcessedReport=${exportProcessedReport}`;

    return this.http.get(url, options).pipe(
      catchError((error: any) => {
        return throwError('Export Failed');
      }),
      map((firstResponse: any) => {
        const jobId = firstResponse.Id;
        return jobId;
      })
    );
}

  getBackgroundJob(backGroundId: string, boardId: string): Observable<any> {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!).authenticated.access_token;
    this.headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
    });
    let options = {
      headers: this.headers,
    };
    const url = this.apiServer.metafireSuiteAPI +`/api/background-jobs/${backGroundId}?boardId=${boardId}`;

    return this.http.get(url, options).pipe(
      catchError((error: any) => {
        return throwError('Failed to fetch background job');
      })
    );
  }



}

