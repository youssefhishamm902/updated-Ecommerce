import { Component, OnInit } from '@angular/core';
import { ReportsService } from "../../shared/services/reports.service";
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-matching-columns',
  templateUrl: './matching-columns.component.html',
  styleUrls: ['./matching-columns.component.scss']
})
export class MatchingColumnsComponent implements OnInit {


  i !: number;
  selectedValue?: string;

  isdisabled: boolean = true;

  isreadonly6: boolean = false;
  isreadonly7: boolean = false;
  isreadonly8: boolean = false;


  orderForm!: FormGroup;
  items!: FormArray;

  dropdown!: any[];

  inputs: string[] = [
    'Track Title', 'Album Name', 'Artist Name', 'UPC', 'ISRC', 'Label', 'Duration', 'Downloads', 'Streams'
  ]

  constructor(private reportservice: ReportsService,
    private formBuilder: FormBuilder,
    private router: Router,
  ) {

  };


  ngOnInit(): void {
    this.dropdown = this.reportservice.dropdown;
    this.orderForm = new FormGroup({
      items: this.formBuilder.array([]),
    });
    this.addItems();
  };

  createItem(name?: string, value?: string): FormGroup {
    return this.formBuilder.group({
      name: [name],
      value: [value, Validators.required]
    });
  }

  createItem2(name?: string, value?: string): FormGroup {
    return this.formBuilder.group({
      name: [name],
      value: [null]
    });
  }

  addItems(): void {
    if (this.reportservice.dropdown) {
      this.items = this.orderForm.get('items') as FormArray;
      this.inputs.forEach((name) => {
        let firststring = name.split(" ");
        let arr = firststring[0];
        let value = this.reportservice.dropdown.find((x) => x.split(" ")[0] == arr);
        if (value) {
          console.log(value);
          this.items.push(this.createItem(name, value));
        }
        else {
          this.items.push(this.createItem(name, value));
        }
      });
    }
  }

  get itemsControls() {
    return (this.orderForm.get('items') as FormArray).controls;
  }
  getControls() {
    return (this.orderForm.get('items') as FormArray).controls;
  }

  onsubmit() {
    this.reportservice.form03 = this.orderForm.value.items;
    this.reportservice.SaveReport().subscribe((res: any) => {
      this.router.navigate(['/reports']);
      this.reportservice.close.next(false);
    });
  }

  check5fields() {
    if (this.orderForm.value.items[0].value &&
      this.orderForm.value.items[1].value &&
      this.orderForm.value.items[2].value &&
      this.orderForm.value.items[3].value &&
      this.orderForm.value.items[4].value &&
      this.orderForm.value.items[5].value) {
      return true
    }
    else {
      return false
    }
  }

  checkDuration() {
    if (this.orderForm.value.items[6].value) {
      this.isreadonly6 = false
      this.isreadonly7 = true
      this.isreadonly8 = true
      if (this.check5fields()) {
        this.isdisabled = false
      }
    }
    if (this.orderForm.value.items[7].value) {
      this.isreadonly6 = true
      this.isreadonly7 = false
      this.isreadonly8 = false
      if (this.check5fields()) {
        this.isdisabled = false
      }
    }
    if (this.orderForm.value.items[8].value) {
      this.isreadonly6 = true
      this.isreadonly7 = false
      this.isreadonly8 = false
      if (this.check5fields()) {
        this.isdisabled = false
      }
    }
  }

  onClearDuration() {
    this.isdisabled = true;
    this.isreadonly6 = false
    this.isreadonly7 = false
    this.isreadonly8 = false
  }

  onClearDOwnStreams() {
    if (this.orderForm.value.items[8].value || this.orderForm.value.items[7].value) {
      this.isdisabled = false;
      this.isreadonly6 = true
    }
    else {
      this.onClearDuration()
    }

  }
}


