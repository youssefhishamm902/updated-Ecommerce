import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router  } from '@angular/router';
import { Subject } from 'rxjs';
import { AppConfig } from 'src/app/app.config';
import { ReportsService } from 'src/app/reports/shared/services/reports.service';
import { Reporter } from '../../shared/models/reporter.model';
import { Report } from '../../shared/models/report.model';
import { SpinnerService } from 'src/core/services/spinner.service';

@Component({
  selector: 'app-report-details',
  templateUrl: './report-details.component.html',
  styleUrls: ['./report-details.component.scss'],
})

export class ReportDetailsComponent implements OnInit {

  myForm = this.fb.group({
    reporter: [{}, Validators.required],
    subtitle: ['', Validators.required],
    period: ['Annual', Validators.required],
    year: [2023, Validators.required], // should add the current year from date
    date: [new Date(), Validators.required],
    time: [new Date(), Validators.required],
  });

  protected apiServer = AppConfig.settings.apiServer;

  reporters: Reporter[] = [];
  periods: string[] = [];
  years: number[] = [];
  today: Date = new Date();
  defaultDate: Date = new Date(this.today);
  deDate: Date = new Date(this.today);
  defaultTime: string = '12:00';
  reportId: any;
  select!: Subject<any>;
  buttonLabel: string = '';
  token: any = JSON.parse(localStorage.getItem('currentUser')!);
  accessToken = this.token.authenticated.access_token;
  currentBoard: string = '';
  currentEditReportId: number = 0;
  filteredData = [];
  currentRow: any;
  editedReportDetails!: Report;
  selectedreporter!:any;


  constructor(
    private router: Router,
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private reportservice: ReportsService,
    private spinnerService: SpinnerService
  ) { }

  ngOnInit(): void {
    this.spinnerService.show();
    this.getLookups();

   this.reportId = this.activatedRoute.snapshot.paramMap.get('id');
    if(this.reportId)
    {
      this.buttonLabel = 'Save changes';
      
    }
    else
    {
      this.buttonLabel = 'Continue';
    }

  }

  getReportDetails(): void {
      const currentBoard = JSON.parse(
        localStorage.getItem('currentUser')!
      ).board.id.toString();
     
      this.reportservice
        .getReportDetails(currentBoard, this.reportId)
        .subscribe((response: Report) => {
          this.editedReportDetails = response;
          const yearValue = response.year;
          const closingDate = new Date(response.closing);
          const closingTime = new Date(response.closing);
          this.selectedreporter = this.reporters.find(
            (x) => x.id === response.reporterId
          )!;
          this.myForm.patchValue({
            reporter: this.selectedreporter,
            subtitle: response.subTitle,
            year: yearValue,
            date: closingDate,
            time: closingTime,
            period:
              response.quarter !== null ? 'Q' + response.quarter : 'Annual',
          });
          this.spinnerService.hide();
        });
  }

  getLookups() {
    this.defaultDate.setDate(this.today.getDate() + 2);
    this.defaultDate.setHours(12);
    this.defaultDate.setMinutes(0);
    this.periods = [
        'Annual' ,
       'Q1' ,
      'Q2' ,
        'Q3' ,
       'Q4' ,
    ];
    this.years = [ //should be a loop that gets the current year and adds the last 5
      2023,
      2022,
      2021,
      2020,
      2019,
    ];
    this.reportservice.getReporters().subscribe((res: Reporter[]) => {
      this.reporters = res;
      if(this.reportId)
      {
        this.getReportDetails();
      }
      else
      {
        this.spinnerService.hide();
      }
    });
  }

  onchange(event: any) {
    this.selectedreporter = event.value;
    this.myForm.patchValue({ reporter: event.value });
  }


  onsubmit() {
    if (this.myForm.valid) {
      this.router.navigate(['/reports/upload-report/Steptwo']);
      this.reportservice.form01 = this.myForm.value;
    }
  }

  saveChanges() {
    this.spinnerService.show();
    this.currentEditReportId = this.editedReportDetails.id;
    this.currentBoard = JSON.parse(
      localStorage.getItem('currentUser')!
    ).board.id;
    let x = this.myForm.value;

    let currentReportDetails = {
      ...this.editedReportDetails,
    };
    currentReportDetails.subTitle = x.subtitle!;
    currentReportDetails.year = x.year!;
    currentReportDetails.closing = x.time!;
    currentReportDetails.quarter =
      x.period == 'Annual' ? '' : x.period!;
currentReportDetails.reporter = x.reporter!;

    this.reportservice
      .saveEditReport(
        this.currentBoard,
        this.currentEditReportId,
        currentReportDetails
      )
      .subscribe((response) => {
        this.router.navigate(['/reports']);
        this.filteredData = response.data;
        this.spinnerService.hide();
      });
  }
}
