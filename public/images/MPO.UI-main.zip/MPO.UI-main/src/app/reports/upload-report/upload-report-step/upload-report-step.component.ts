import { Component, ViewChild } from '@angular/core';
import { FileUpload } from 'primeng/fileupload';
import { Router } from "@angular/router"
import { AppConfig } from "../../../app.config";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ReportsService } from "../../shared/services/reports.service";

@Component({
  selector: 'app-upload-step-report',
  templateUrl: './upload-report-step.component.html',
  styleUrls: ['./upload-report-step.component.scss']
})
export class UploadReportStepComponent {
  @ViewChild('fileUpload', { static: false }) FileUpload!: FileUpload;

  uploadedFile: any;
  isempty: boolean = true;
  protected apiServer = AppConfig.settings.apiServer
  headers!: HttpHeaders;

  token: any = JSON.parse(localStorage.getItem('currentUser')!);
  accessToken = this.token.authenticated.access_token

  constructor(private router: Router,
    public http: HttpClient,
    private reportservice: ReportsService) { }


  onUpload(file: any) {
    this.uploadedFile = file;
  }

  onselect(file: any) {
    this.isempty = false;
    this.uploadedFile = file.currentFiles[0];
    this.reportservice.UploadFile(this.uploadedFile);
  }


  onclear() {
    this.uploadedFile = null;
    this.isempty = true;
  }
  onCustomLinkClick() {
    this.FileUpload.choose();
  }

  routing() {
    if (this.uploadedFile) {
      this.router.navigate(['/reports/upload-report/Stepthree']);
    }
  }
}





