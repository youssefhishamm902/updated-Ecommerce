import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-upload-report',
  templateUrl: './upload-report.component.html',
  styleUrls: ['./upload-report.component.scss']
})
export class UploadReportComponent implements OnInit {

  items: MenuItem[] = [];
  visible: boolean = false;

  constructor( private router: Router) {}

  ngOnInit(): void {
    this.items = [
      {
        label: 'Report details',
        routerLink: 'Stepone',
      },
      {
        label: 'Upload report',
        routerLink: 'Steptwo',
      },
      {
        label: 'Matching columns',
        routerLink: 'Stepthree',
      },
    ];
    this.showDialog();
  }
  showDialog() {
    this.visible = true;
  }
  closeDialog(){
    this.visible=false;
    this.router.navigate(['/reports']);
  }
}
