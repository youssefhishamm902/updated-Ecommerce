import { AppConfig } from '../../../app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class StatisticsService {
  protected apiServer = AppConfig.settings.apiServer;
  headers = new HttpHeaders();

  constructor(private http: HttpClient, private appConfig: AppConfig) {
    let token: any = JSON.parse(localStorage.getItem('currentUser')!)
      .authenticated.access_token;
    this.headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
    });
  }
  getData1ToSelectLabel(): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.authAPI +
      `/boards?filter[productType]=MetafireSuite&filter.excludeRootBoard=true&page%5Bnumber%5D=0&page%5Bsize%5D=1000&rootFirst=true&sort=title`;
    return this.http.get(url, options);
  }
  getData2ToSelectLabel(): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.authAPI +
      `/boards?filter[productType]=MetafireSuite&filter.excludeRootBoard=true&page%5Bnumber%5D=1&page%5Bsize%5D=1000&rootFirst=true&sort=title`;
    return this.http.get(url, options);
  }
  getClientsData(boardId: string): Observable<any> {
    let options = { headers: this.headers };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports?boardId=${boardId}&isCountersRequired=false&includeCounters=false&page.limit=1000&page.offset=0`;
    return this.http.get(url, options);
  }
  updatePerformance(boardIds: any, reportIds: any): Observable<any> {
    let options = { headers: this.headers };
    let body = { boardsIds: boardIds, reportsIds: reportIds };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/Statistics/performance?boardId=ad913cf6-8ef1-4a35-873f-d29f7d77c7ec&page.offset=0&page.limit=100`;

    return this.http.post(url, body, options);
  }
  updateRevenue(
    boardIds: any,
    fromDate: string,
    reportIds: any,
    toDate: string
  ): Observable<any> {
    let options = { headers: this.headers };
    let body = {
      boardsIds: boardIds,
      fromDate: fromDate,
      reportsIds: reportIds,
      toDate: toDate,
    };
    let url =
      this.apiServer.metafireSuiteAPI +
      `/api/Statistics/revenue?boardId=ad913cf6-8ef1-4a35-873f-d29f7d77c7ec&page.offset=0&page.limit=100`;

    return this.http.post(url, body, options);
  }
  export(boardId: string, boardIds: any, reportIds: any): Observable<any> {
    let options = {
      headers: this.headers,
    };
    let body = {
      boards: boardIds,
      reportStatus: ['Unpublished', 'Open', 'Closed'],
      reports: reportIds,
    };
    const url =
      this.apiServer.metafireSuiteAPI +
      `/api/reports/all/export?boardId=${boardId}`;
    return this.http.post(url, body, options);
  }
  getBackgroundJob(backGroundId: string, boardId: string): Observable<any> {
    let options = { headers: this.headers };
    const url =
      this.apiServer.metafireSuiteAPI +
      `/api/background-jobs/${backGroundId}?boardId=${boardId}`;
    return this.http.get(url, options);
  }
}
