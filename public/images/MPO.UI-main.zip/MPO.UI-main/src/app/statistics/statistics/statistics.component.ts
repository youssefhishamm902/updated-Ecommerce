import { Component, OnInit, ViewChild } from '@angular/core';
import { StatisticsService } from '../shared/services/statistics.service';
import { Calendar } from 'primeng/calendar';
import { MessageService } from 'primeng/api';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-statistics',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.scss'],
})
export class StatisticsComponent implements OnInit {
  currentBoard: string = '';

  Labels: any[] = [];
  selectedLabels: any[] = [];

  selectedYears: any[] = [];
  ReportingYears: any[] = [];

  Clients: any[] = [];
  selectedClients: any[] = [];
  filteredClients: any[] = [];

  LabelsIds: any[] = [];
  ClientsIds: any[] = [];

  selectedTab: number = 0;

  Artists: any[] = [];
  Albums: any[] = [];
  Tracks: any[] = [];
  Stats: any = {};
  tableData: any[] = [];

  labelsStr: string = '';
  clientsStr: string = '';

  showchart: boolean = false;
  showtable: boolean = false;
  DataOptions: any[] = [
    { name: 'Artists' },
    { name: 'Albums' },
    { name: 'Tracks' },
  ];
  selectedData: any = { name: 'Artists' };

  data: any;
  selectedRange: Date[] = [new Date(2022, 0, 1), new Date()];
  selectedRange2: Date[] = [new Date(2022, 0, 1), new Date()];
  selectedPeriod: any = '';
  rangeOptions: any[] = [
    {
      label: 'Period',
      value: 'period',
      displayDate: [new Date(2022, 0, 1), new Date()],
    },
    {
      label: 'All time',
      value: 'all',
      displayDate: [new Date(2022, 0, 1), new Date()],
    },
    { label: 'Today', value: 'today', displayDate: [] },
    { label: 'Yesterday', value: 'yesterday', displayDate: [] },
    { label: 'Past 7 days', value: 'past7', displayDate: [] },
    { label: 'Past 30 days', value: 'past30', displayDate: [] },
    { label: 'First day', value: 'firstday', displayDate: [] },
    { label: 'First 7 days', value: 'first7', displayDate: [] },
    {
      label: 'First 30 days',
      value: 'first30',
      displayDate: [],
    },
    { label: 'Custom', value: 'custom', displayDate: [] },
  ];
  @ViewChild('calendar') calendar: Calendar | undefined;
  formattedDate1: any;
  formattedDate2: any;
  pageSizeOptions = [
    { name: '10 pr. page', value: 10 },
    { name: '20 pr. page', value: 20 },
    { name: '50 pr. page', value: 50 },
    { name: '100 pr. page', value: 100 },
  ];
  selectedPageSize: number = 10;
  allItems: any[] = [];
  failed: boolean = false;
  exportTimeout: number = AppConfig.settings.exportTimeout;

  constructor(
    private statisticsService: StatisticsService,
    private messageService: MessageService
  ) {
    this.currentBoard = String(
      JSON.parse(localStorage.getItem('currentUser')!).board.id
    );
  }
  ngOnInit(): void {
    this.getDatatoSelectLabel();
    for (let i = new Date().getFullYear(); i >= 2015; i--) {
      this.ReportingYears.push(i);
    }
    this.getClientsData();
  }

  getDatatoSelectLabel() {
    this.statisticsService.getData1ToSelectLabel().subscribe({
      next: (response) => {
        let data1 = response.data;
        let i = 0;
        for (i = 0; i < data1.length; i++) {
          this.Labels[i] = {
            id: data1[i].id,
            label: data1[i].attributes.title,
          };
        }
        this.statisticsService.getData2ToSelectLabel().subscribe({
          next: (response) => {
            let data2 = response.data;
            for (let j = 0; j < data2.length; j++) {
              this.Labels[i] = {
                id: data2[j].id,
                label: data2[j].attributes.title,
              };
              i++;
            }
          },
        });
      },
    });
  }

  getClientsData() {
    this.statisticsService.getClientsData(this.currentBoard).subscribe({
      next: (response) => {
        for (let i = 0; i < response.Data.length; i++) {
          let quarter = response.Data[i].Quarter
            ? '' + response.Data[i].Quarter
            : 'Annual';
          this.Clients[i] = {
            id: response.Data[i].Id,
            label:
              response.Data[i].Reporter.Name +
              '.' +
              quarter +
              '.' +
              response.Data[i].Year,
            subTitle: response.Data[i].SubTitle,
          };
          this.filteredClients = this.Clients;
        }
      },
    });
  }

  onSelectLabel(event: any) {
    console.log(this.selectedLabels);
  }
  onSelectYear() {
    this.filteredClients = this.Clients.filter((client) => {
      return this.selectedYears.some((year) => client.label.includes(year));
    });
    if (this.filteredClients.length == 0) {
      this.filteredClients = this.Clients;
    }
    this.selectedClients = [];
  }
  onSelectClient(event: any) {
    console.log(this.selectedClients);
  }

  handleTabChange(event: any) {
    this.selectedLabels = [];
    this.selectedClients = [];
    this.selectedYears = [];
    this.ReportingYears = [];
    this.selectedTab = event.index;
    this.showchart = false;
    this.tableData = [];
    if (this.selectedTab == 0) {
      for (let i = new Date().getFullYear(); i >= 2015; i--) {
        this.ReportingYears.push(i);
      }
      this.filteredClients = this.Clients;
    } else if (this.selectedTab == 1) {
      let lastYear = new Date().getFullYear() - 1;
      for (let i = lastYear; i >= 2015; i--) {
        this.ReportingYears.push(i);
      }
      this.filteredClients = this.Clients.filter((client) => {
        if (!client.label.includes(lastYear + 1)) return client.label;
      });
    }
  }

  updatePerformance() {
    this.labelsStr = '';
    this.clientsStr = '';
    this.tableData = [];
    this.LabelsIds = [];
    this.ClientsIds = [];
    this.selectedLabels.forEach((label) => {
      this.labelsStr += label.label + ', ';
      this.LabelsIds.push(label.id);
    });
    this.selectedClients.forEach((client) => {
      this.clientsStr += client.label + ', ';
      this.ClientsIds.push(client.id);
    });

    this.statisticsService
      .updatePerformance(this.LabelsIds, this.ClientsIds)
      .subscribe({
        next: (response) => {
          this.Artists = response.Artists;
          this.Albums = response.Releases;
          this.Tracks = response.Tracks;
          this.Stats = response.Stats;
          this.tableData = this.Artists;
          this.data = {
            datasets: [
              {
                data: [
                  this.Stats.Assigned,
                  this.Stats.AssignedToOthers,
                  this.Stats.Unclaimed,
                ],
                backgroundColor: ['#378EF0', '#FA9E42', '#D83790'],
              },
            ],
          };
          this.showchart = true;
        },
      });
  }

  onSelect() {
    this.tableData = [];
    if (this.selectedData.name == 'Artists') {
      this.tableData = this.Artists;
    } else if (this.selectedData.name == 'Albums') {
      this.tableData = this.Albums;
    } else if (this.selectedData.name == 'Tracks') {
      this.tableData = this.Tracks;
    }
    this.allItems = this.tableData;
    this.onPageSizeChange();
  }
  onSelectDate() {
    this.selectedRange = [this.selectedRange2[0], this.selectedRange2[1]];
    console.log(this.selectedRange);
  }
  SetPeriod(event: any) {
    this.selectedPeriod = event.value;
    switch (this.selectedPeriod) {
      case 'all':
        this.selectedRange = [new Date(2013, 0, 1), new Date()];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'today':
        this.selectedRange = [new Date(), new Date()];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'yesterday':
        this.selectedRange = [
          new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            new Date().getDate() - 1
          ),
          new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            new Date().getDate() - 1
          ),
        ];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'past7':
        this.selectedRange = [
          new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            new Date().getDate() - 6
          ),
          new Date(),
        ];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'past30':
        this.selectedRange = [
          new Date(
            new Date().getFullYear(),
            new Date().getMonth(),
            new Date().getDate() - 29
          ),
          new Date(),
        ];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'firstday':
        this.selectedRange = [new Date(2013, 0, 1), new Date(2013, 0, 1)];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'first7':
        this.selectedRange = [new Date(2013, 0, 1), new Date(2013, 0, 7)];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'first30':
        this.selectedRange = [new Date(2013, 0, 1), new Date(2013, 0, 30)];
        this.selectedRange2 = this.selectedRange;
        break;
      case 'custom':
        this.selectedRange = [new Date(2022, 0, 1), new Date()];
        this.selectedRange2 = this.selectedRange;
        setTimeout(() => {
          this.calendar?.inputfieldViewChild?.nativeElement.click();
        }, 0);

        break;
    }
    this.rangeOptions[0].displayDate = this.selectedRange;
  }
  updateRevenue() {
    this.tableData = [];
    this.LabelsIds = [];
    this.ClientsIds = [];
    this.selectedLabels.forEach((label) => {
      this.LabelsIds.push(label.id);
    });
    this.selectedClients.forEach((client) => {
      this.ClientsIds.push(client.id);
    });
    let date1 = this.selectedRange2[0]
      .toLocaleDateString('en-GB', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      })
      .split('/')
      .reverse()
      .join('-');
    let date2 = this.selectedRange2[1]
      .toLocaleDateString('en-GB', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      })
      .split('/')
      .reverse()
      .join('-');
    this.statisticsService
      .updateRevenue(this.LabelsIds, date1, this.ClientsIds, date2)
      .subscribe({
        next: (response) => {
          this.Artists = response.Artists;
          this.Albums = response.Releases;
          this.Tracks = response.Tracks;
          this.tableData = this.Artists;
          this.allItems = this.tableData;
          this.onPageSizeChange();
          this.showtable = true;
        },
      });
  }
  onPageSizeChange() {
    this.tableData = this.allItems.slice(0, this.selectedPageSize);
  }

  exportDataToExcel() {
    //call first api
    let JobId = '';
    this.LabelsIds = [];
    this.ClientsIds = [];
    this.selectedLabels.forEach((label) => {
      this.LabelsIds.push(label.id);
    });
    this.selectedClients.forEach((client) => {
      this.ClientsIds.push(client.id);
    });
    if (this.ClientsIds.length == 0) {
      for (let i = 0; i < this.Clients.length; i++) {
        this.ClientsIds[i] = this.Clients[i].id;
      }
    }
    this.statisticsService
      .export(this.currentBoard, this.LabelsIds, this.ClientsIds)
      .subscribe({
        next: (response) => {
          this.messageService.add({
            severity: 'info',
            summary: 'Export Started',
            detail:
              'Export of Filtered report items have been started. Please do not leave this screen - you will be notified when export is done.',
          });
          JobId = response.Id;
          //call second api
          this.checkJobStatus(JobId);
        },
        error: (error: any) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Export Failed',
            detail: 'An error occurred while exporting data. Please try again.',
          });
        },
      });
  }

  checkJobStatus(JobId: string) {
    this.statisticsService
      .getBackgroundJob(JobId, this.currentBoard)
      .subscribe({
        next: (response) => {
          if (response.Status === 'Passed' && response.Result != null) {
            const exportUri = response.Result.ExportedReportUri;
            window.open(exportUri, '_blank');
            this.messageService.add({
              severity: 'success',
              summary: 'Export Finished',
              detail: 'Filtered report items are exported successfully!',
            });
          } else {
            if (!this.failed) {
              setTimeout(() => {
                this.checkJobStatus(JobId);
              }, this.exportTimeout);
            }
          }
        },
        error: (error: any) => {
          this.failed = true;
          this.messageService.add({
            severity: 'error',
            summary: 'Export Failed',
            detail: 'An error occurred while exporting data. Please try again.',
          });
        },
      });
  }
}
