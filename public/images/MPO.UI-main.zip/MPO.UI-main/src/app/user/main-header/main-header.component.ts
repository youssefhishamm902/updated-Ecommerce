import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MenuItem } from 'primeng/api';
import { AuthenticationService } from '../../../core/services/authentication.service';
import { environment } from 'src/environments/environment.production';

@Component({
  selector: 'app-main-header',
  templateUrl: './main-header.component.html',
  styleUrls: ['./main-header.component.scss'],
})
export class MainHeaderComponent {
  items: MenuItem[] | undefined;
  userMenuItems: MenuItem[] | undefined;
  Name!: string;
  currentUser: any;

  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private translate: TranslateService
  ) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser')!);
    this.translate.setDefaultLang(environment.language1);
    this.translate.use(environment.language1);
    if (this.currentUser != null || '') {
      this.Name =
        this.currentUser.user.firstName + ' ' + this.currentUser.user.lastName;
      console.log(this.Name);
    }
  }
  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
    this.authService.loggedIn.next(false);
  }
  ngOnInit() {
    this.userMenuItems = [
      {
        label: this.Name,
        //icon: 'pi pi-user',
        items: [
          {
            label: 'Profile settings',
            icon: 'pi pi-user',
            command: () => {
              this.router.navigate(['/profile-settings']);
              //this.authService.isProfileSettings.next(true);
            },
          },
          {
            label: 'Sign out',
            icon: 'pi pi-fw pi-sign-out',
            command: () => {
              this.logout();
            },
          },
        ],
      },
    ];

    this.items = [
      {
        label: 'Reports',
        //icon: 'pi pi-fw pi-power-off'
        icon: 'pi pi-fw pi-file',
        command: () => {
          this.selectItem('Reports');
          this.router.navigate(['/reports']);
        },
      },
      {
        label: 'Report Items',
        icon: 'pi pi-fw pi-list',
        //icon: 'pi pi-fw pi-power-off'
        command: () => {
          this.selectItem('Report Items');
          this.router.navigate(['/report-items']);
        },
      },
      {
        label: 'Disputes',
        //icon: 'pi pi-fw pi-power-off'
        icon: 'fa-solid fa-scale-unbalanced',

        command: () => {
          this.selectItem('Disputes');
          this.router.navigate(['/disputes']);
        },
      },
      {
        label: 'Statistics',
        icon: 'pi pi-fw pi-chart-line',
        command: () => {
          this.selectItem('Statistics');
          this.router.navigate(['/statistics']);
        },
      },
      {
        label: 'Finance',
        icon: 'pi pi-fw pi-money-bill',
        command: () => {
          this.selectItem('Finance');
          this.router.navigate(['/finance']);
        },
      },
      {
        label: 'Admin Tools',
        icon: 'pi pi-shield',
        items: [
          {
            label: 'User Management',
            icon: 'pi pi-fw pi-user',
            command: () => {
              this.selectItem('Admin Tools');
              this.router.navigate(['/user-management']);
            },
          },
          {
            label: 'Label Management',
            //icon: 'pi pi-fw pi-external-link'
            command: () => {
              this.selectItem('Admin Tools');
              this.router.navigate(['/label-management']);
            },
          },
          {
            label: 'Alias Management',
            //icon: 'pi pi-fw pi-external-link'
            command: () => {
              this.selectItem('Admin Tools');
              this.router.navigate(['/alias-management']);
            },
          },
          {
            label: 'E-mail Sender',
            icon: 'pi pi-envelope',
            command: () => {
              this.selectItem('Admin Tools');
              this.router.navigate(['/emailsender']);
            },
          },
        ],
      },
    ];
  }
  selectItem(label: string): void {
    this.items?.forEach((menuItem) => {
      menuItem.styleClass = menuItem.label === label ? 'active' : '';
    });
  }
}
