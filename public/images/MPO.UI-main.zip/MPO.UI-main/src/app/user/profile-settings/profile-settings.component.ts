import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FileUpload } from 'primeng/fileupload';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MenuItem } from 'primeng/api';
import { AuthenticationService } from "../../../core/services/authentication.service";
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-profile-settings',
  templateUrl: './profile-settings.component.html',
  styleUrls: ['./profile-settings.component.scss']
})
export class ProfileSettingsComponent implements OnInit, OnDestroy {
  @ViewChild('fileUpload', { static: false }) FileUpload!: FileUpload;

  uploadedImage!: string;

  activeTab: string = 'Profile';
  activeItem!: MenuItem;
  ProfileForm!: FormGroup;
  PasswordForm!: FormGroup;
  uploadedFile: any;


  userdata: any = JSON.parse(localStorage.getItem('currentUser')!);
  user = this.userdata.user;
  isdisable!: boolean;

  menuItems: MenuItem[] = [
    { label: 'Profile', command: () => this.activeTab = 'Profile' },
    { label: 'Password', command: () => this.activeTab = 'Password' },
    // Add more menu items with commands for other tabs
  ];
  profileImage: any;
  // router: any;

  constructor(private fb: FormBuilder,
    private AuthenticationService: AuthenticationService,
    private route: ActivatedRoute,
    private router: Router

    // private ReportsService: ReportsServiceService
  ) { }


  ngOnInit() {
    // this.router.events.subscribe(event => {
    //   if (event instanceof NavigationEnd) {

    //     this.AuthenticationService.isProfileSettings.next(true)
    //   }
    // });
    // debugger;
    this.AuthenticationService.isProfileSettings.next(true)

    this.activeItem = this.menuItems[0];

    console.log(this.route.component)

    this.ProfileForm = this.fb.group({
      'FirstName': [this.user.firstName, Validators.required],
      'LastName': [this.user.lastName, Validators.required],
      'Email': [this.user.email, Validators.required],
      'PhoneNumber': [this.user.phoneNumber, Validators.required],
      'JobTitle': [this.user.position, Validators.required],
      'hasImage': [this.user.hasImage]
    })
    this.PasswordForm = this.fb.group({
      'CurrentPassword': ['', Validators.required],
      'Password': ['', Validators.required],
      'ConfirmPassword': ['', Validators.required]
    })
  }

  onTabChange(event: any) {
    this.activeTab = event.index === 0 ? 'Profile' : 'Password';
  }

  forgetPassword() {
    this.AuthenticationService.forgetPassword().subscribe(res => {
      console.log(res);
    });
  }
  onCustomLinkClick() {
    this.FileUpload.choose();
  }
  onselect(file: any) {
    // debugger;
    // this.uploadedFile = file.currentFiles[0];
    this.uploadedFile = file;
    console.log(file)
    this.AuthenticationService.imageReq(file).subscribe((res: any) => {
      // debugger;
      this.uploadedImage = res.Uri;
      // if (file.files && file.files.length > 0) {
      //   const file01 = this.uploadedFile.currentFiles[0];
      //   console.log(res.Uri)
      //   const reader = new FileReader();
      //   reader.onload = (e: any) => {
      //     this.uploadedImage = e.target.result;
      //     // this.AuthenticationService.ProfileImage.next(this.uploadedImage);
      //   };
      //   reader.readAsDataURL(file01);
      // }
    });
  }


  onchange() {
    if (this.ProfileForm.valid) {
      this.isdisable = false
    }
    else {
      this.isdisable = false
    }
  }

  submitForm() {
    // debugger;
    // if (this.ProfileForm.valid) {
    this.AuthenticationService.submitProfileForm(this.ProfileForm);
    console.log(this.ProfileForm);
    // if (this.profileImage) {
    // }
    // }
  }
  routing() {
    this.router.navigate(['/reports']);
  }

  removeImage() {
    this.uploadedImage = '';
    this.AuthenticationService.ProfileImage.next('');
  }

  ngOnDestroy() {
  }
}
