import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ProfileSettingsComponent } from './profile-settings/profile-settings.component';
import { SharedModule } from '../../shared/components/shared.module';

const routes: Routes = [
  {
    path: '',
    component: ProfileSettingsComponent
  },
];

@NgModule({
  declarations: [
    ProfileSettingsComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    SharedModule,
    CommonModule
  ]
})
export class UserModule { }
