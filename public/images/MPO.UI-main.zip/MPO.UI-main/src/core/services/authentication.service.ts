import { Injectable, booleanAttribute } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { BehaviorSubject, Observable, Subject, Subscription, of } from "rxjs";
import { map } from 'rxjs/operators';
import { AppConfig } from '../../app/app.config';
import Jsona from 'jsona';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
const dataFormatter = new Jsona();

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  protected apiServer = AppConfig.settings.apiServer;
  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: any = null;
  body000!: any;
  token = JSON.parse(localStorage.getItem("currentUser")!);

  ProfileImage: Subject<any> = new Subject<any>();

  isProfileSettings: Subject<any> = new Subject<any>();

  public ProfileSubmitting = new BehaviorSubject<any>('')

  public loggedIn = new BehaviorSubject<boolean>(false); // {1}

  loggedinSubscribtion: Subscription = this.loggedIn.subscribe((res: boolean) => {
    this.ProfileSubmitting.next(this.fb.group({
      'FirstName': [this.token.user.firstName],
      'LastName': [this.token.user.lastName],
      'Email': [this.token.user.email],
      'PhoneNumber': [this.token.user.phoneNumber],
      'JobTitle': [this.token.user.position],
      'hasImage': [this.token.user.hasImage]
    }))
  })

  get isLoggedIn(): Observable<boolean> {
    return this.loggedIn.asObservable(); // {2}
    // {1}
  }

  constructor(private http: HttpClient, private fb: FormBuilder) {
    this.currentUserSubject = new BehaviorSubject<any>(
      JSON.parse(localStorage.getItem("currentUser")!)
    );
    this.currentUser = this.currentUserSubject.asObservable();

    this.ProfileImage.subscribe((res: any) => {
      this.body000 = res;
      console.log(res)
    });
  }

  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }
  imageReq(uploadedFile: any) {
    // debugger;
    const bodyContent = new FormData();
    bodyContent.append("file", uploadedFile.files[0]);

    return this.http.post(this.apiServer.metafireSuiteAPI + `/api/upload/file`,
      bodyContent, {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + this.token.authenticated.access_token
        // 'Content-Type': 'application/vnd.api+json'
      })
    }

    )
  }

  submitProfileForm(Form: any) {
    //debugger;
    const body: any = {
      "data": {
        "id": this.token.user.id,
        "type": "users",

        "attributes": {
          "firstName": Form.value.FirstName,
          "lastName": Form.value.LastName,
          "email": Form.value.Email,
          "hasImage": Form.value.hasImage,
          "userType": "BoardUser",
          "isActive": true,
          "createdDate": "2023-07-10T08:58:33.03",
          "phoneNumber": Form.value.PhoneNumber,
          "position": Form.value.JobTitle
        },
        "relationships": {
          "invitation": {
            "data": {
              "id": "abdb0d8a-d203-4a02-8d90-6368dd6015bd",
              "type": "invitations"
            }
          },
          "organisations": {
            "data": [
              {
                "id": this.token.board.organisation.id,
                // "id": "2195ed89-bd12-4e27-9bdf-d8fcd9b8f14d",
                "type": "organisations"
              }
            ]
          }
        }
      },
      "meta": {
        "transactionId": "f4898835-1d00-4b9b-8b4e-8371a3b344f6"

      }
    }

    console.log(body);
    this.http.patch(this.apiServer.authAPI + `/users/` + this.token.user.id,
      body, {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + this.token.authenticated.access_token,
        'Content-Type': 'application/vnd.api+json'
      })
    }

    ).subscribe()
  }

  login(username: string, password: string) {
    //debugger;
    // post to fake back end, this url will be handled there...
    let httpParams = new HttpParams()
      .append('grant_type', 'password')
      .append('username', username)
      .append('password', password)
      .append('client_id', 'metafire.js')
      .append('client_secret', 'v9DRw3CqfhDPS8sHLtWr5V79')
      .append('scope', 'metafire.suite offline_access');

    let headers = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      Vary: 'Accept-Encoding',
    });
    let options = { headers: headers };

    return (
      this.http
        //.post(`https://mf3-test-authentication.azurewebsites.net/identity/connect/token`,
        .post(
          this.apiServer.authAPI + `/identity/connect/token`,
          httpParams,
          options
        )
    );
  }

  getCurrentUserDetails(token: string) {
    //let token: any = JSON.parse(localStorage.getItem('currentUser')!).authenticated.access_token;
    let headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
      //'Set-Cookie': 'Accept-Encoding'
    });
    let options = { headers: headers };


    return this.http
      .get(this.apiServer.authAPI + `/users/current`, options)
      .pipe(
        map((response: any) =>
          dataFormatter.deserialize(response, {
            preferNestedDataFromData: true,
          })
        )
      );
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.loggedIn.next(false);
    this.currentUserSubject.next(null);
  }

  getCurrentBoardPermissions(token: string) {
    let headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
      //'Set-Cookie': 'Accept-Encoding'
    });
    let options = { headers: headers };

    return this.http
      .get(
        this.apiServer.authAPI +
          `/boards?filter[productType]=MetafireSuite&filter.excludeRootBoard=false&page%5Bnumber%5D=0&page%5Bsize%5D=3&rootFirst=true&sort=-VisitDate`,
        options
      )
      .pipe(
        map((response: any) =>
          dataFormatter.deserialize(response, {
            preferNestedDataFromData: true,
          })
        )
      );
  }

  getCurrentBoard(boardId: string, token: string) {
    let headers = new HttpHeaders({
      Authorization: 'Bearer ' + token,
      //'Set-Cookie': 'Accept-Encoding'
    });
    let options = { headers: headers };

    return this.http
      .get(this.apiServer.authAPI + `/boards/` + boardId, options)
      .pipe(
        map((response: any) =>
          dataFormatter.deserialize(response, {
            preferNestedDataFromData: true,
          })
        )
      );
  }

  forgetPassword() {
    return this.http.post(this.apiServer.authAPI + `/forgotpassword`,
      {
        "data": {
          "type": "string",
          "attributes": {
            "email": this.token.user.email,
            "product": "MetafireSuite"
          }
        }
      }, {
      headers: new HttpHeaders({
        'Content-Type': 'application/vnd.api+json'
      })
    })
  }
}
