import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SpinnerService {
  visibility: BehaviorSubject<boolean>;

  pendingRequests = 0;

  constructor() {
    this.visibility = new BehaviorSubject(false);
  }

  show() {
    this.pendingRequests++;
    this.visibility.next(true);
  }

  hide() {
    this.pendingRequests--;
    if (this.pendingRequests < 1) {
      this.pendingRequests = 0;
      this.visibility.next(false);
    }
  }
}
