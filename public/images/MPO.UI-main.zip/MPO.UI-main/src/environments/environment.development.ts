export const environment = {
    name: 'development'
};
