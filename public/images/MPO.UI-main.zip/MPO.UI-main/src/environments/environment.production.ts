export const environment = {
  name: 'production',
  language1: "eng",
  // reporterImageURL: `https:s3-eu-west-1.amazonaws.com/mpo-suite-test/reporters/${i}/static/image`
};
