export const environment = {
    name: 'test'
};
