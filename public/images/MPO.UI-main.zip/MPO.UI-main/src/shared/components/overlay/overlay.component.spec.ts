import {
  async,
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
} from '@angular/core/testing';
import { of } from 'rxjs';
import { SpinnerService } from 'src/core/services/spinner.service';
import { MockSpinnerService } from 'src/mockClasses/spinner-service';
import { SharedModule } from 'src/shared/shared.module';

import { OverlayComponent } from './overlay.component';

describe('OverlayComponent', () => {
  let component: OverlayComponent;
  let fixture: ComponentFixture<OverlayComponent>;

  let spinnerService: MockSpinnerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: [OverlayComponent],
      providers: [{ provide: SpinnerService, useClass: MockSpinnerService }],
    }).compileComponents();
  }));

  beforeEach(() => {
    spinnerService = TestBed.inject(SpinnerService);
    spyOn(spinnerService.visibility, 'subscribe').and.callThrough();

    fixture = TestBed.createComponent(OverlayComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('set isLoading to true', () => {
    expect(component.isLoading).toBe(true);
  });

  it('subscribe to spinnerService.visibility and change is loading', fakeAsync(() => {
    expect(component.spinnerService.visibility.subscribe).toHaveBeenCalled();
    expect(component.isLoading).toBe(true);
    component.spinnerService.visibility.next(false);
    tick(0);
    expect(component.isLoading).toBe(false);
  }));
});
