import { Component } from '@angular/core';
import { SpinnerService } from '../../../core/services/spinner.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@Component({
  selector: 'app-overlay',
  templateUrl: './overlay.component.html',
  styleUrls: ['./overlay.component.scss'],
})

export class OverlayComponent {
  isLoading = true;
  constructor(public spinnerService: SpinnerService) {
    this.spinnerService.visibility.subscribe((isLoading) => {
      // using setTimeout with 0 ms because of this issue : https://github.com/angular/angular/issues/17572
      setTimeout(() => {
        this.isLoading = isLoading;
      }, 0);
    });
  }
}
