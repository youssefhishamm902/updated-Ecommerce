import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent {
  @Input() btnlabel !: string;
  @Input() bordertype!: string;
  @Input() color !: string;
  @Input() btnIcon !: string;
  @Input() type !: string;
  @Input() isdisabled: boolean = false;

  constructor() { }

}
