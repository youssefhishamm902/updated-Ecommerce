export interface PaginationConfig {
  pageIndex: number;
  pageSize: number;
}

export interface DataTableConfig {
  searchString: string;
  sortOrder: string;
  sortProperty: string;
  paginationConfig: PaginationConfig;
}

export const DefaultDataTableConfig: DataTableConfig = {
  searchString: '',
  sortOrder: '',
  sortProperty: '',
  paginationConfig: {
    pageIndex: 1,
    pageSize: 10,
  },
};

export interface PaginatedData {
  total: number;
}
